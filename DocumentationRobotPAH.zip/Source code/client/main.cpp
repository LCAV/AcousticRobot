/* 
		PAH client
		Julien Tharin, 2014
		The client connects to the server.
		It can be stopped with q key

*/


#include <stdio.h>
#include <sys/types.h>

#ifdef WIN32
 #include <winsock2.h>
 #define bcopy(s2,s1,n) memcpy(s1, s2, n)
 #define bzero(s1,s2) memset(s1,0,s2)
 #include <conio.h>
 #include <windows.h> 
#else
 #include <sys/socket.h>
 #include <netinet/in.h>
 #include <arpa/inet.h>
 #include <netdb.h>
 #import <fcntl.h>
#endif



#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>

#define DEBUG 1

/*--------------------------------------------------------------------*/


#define DEFAULT_SERVER_PORT 51717

#define DEFAULT_SERVER_IP "192.168.192.44"

#define SOCKET_MAX_SIZE 31 // socket read/write buffer size

static int sockfd; // socket file descriptor number

static int quitReq=0; // boolean qui request variable

static int connected=0; 

struct sockaddr_in serv_addr;  // server address struct

LARGE_INTEGER StartingTime, EndingTime, ElapsedMicroseconds;
LARGE_INTEGER Frequency;

/*----------------------- FUNCTIONS ----------------------------------*/
/*--------------------------------------------------------------------*/

//gotoxy function
/*void gotoxy(int x,int y)
{
printf("%c[%d;%df",0x1B,y,x);
}*/

/*--------------------------------------------------------------------*/
/*!
 * Move screen cursor to position
 *
 * \param column right
 *				line down
 *
 * \return no return
 */
void gotoxy(int column,int line)
{
    COORD coord = {column,line};
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}



/*--------------------------------------------------------------------*/
/*!
 * Move screen cursor x position
 *
 * \param x right
 *
 * \return no return
 */
void gotox(int x)
{
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    PCONSOLE_SCREEN_BUFFER_INFO pcsbi=&csbi;
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE),pcsbi);
    COORD coord = {x,csbi.dwCursorPosition.Y};
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
}

/*--------------------------------------------------------------------*/
/*!
 *  Hide cursor
 *
 * \param none
 *				
 *
 * \return no return
 */
void hidecursor(void) {
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
   CONSOLE_CURSOR_INFO info;
   info.dwSize = 5;
   info.bVisible = false;
   SetConsoleCursorInfo(consoleHandle, &info);
}

/*--------------------------------------------------------------------*/
/*!
 *  Show cursor
 *
 * \param none
 *				
 *
 * \return no return
 */
void showcursor(void) {
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
   CONSOLE_CURSOR_INFO info;
   info.dwSize = 5;
   info.bVisible = true;
   SetConsoleCursorInfo(consoleHandle, &info);
}

/*--------------------------------------------------------------------*/
/*!
 *  Clear console screen
 *
 * \param none
 *				
 *
 * \return no return
 */
void clrscr(){
	//cls( GetStdHandle( STD_OUTPUT_HANDLE));
	system("cls");
}

/*!
 * Compute time difference
 *

 * \param difference difference between the two times, in structure timeval type
 * \param end_time end time
 * \param start_time start time  
 *
 * \return difference between the two times in [us]
 *
 */
long long
timeval_diff(struct timeval *difference,
             struct timeval *end_time,
             struct timeval *start_time
            )
{
  struct timeval temp_diff;

  if(difference==NULL)
  {
    difference=&temp_diff;
  }

  difference->tv_sec =end_time->tv_sec -start_time->tv_sec ;
  difference->tv_usec=end_time->tv_usec-start_time->tv_usec;

  /* Using while instead of if below makes the code slightly more robust. */

  while(difference->tv_usec<0)
  {
    difference->tv_usec+=1000000;
    difference->tv_sec -=1;
  }

  return 1000000LL*difference->tv_sec+
                   difference->tv_usec;

} /* timeval_diff() */



int sendData( int sockfd,char *buffer,int len ) {
  int n;

  
  #ifdef WIN32
  if ( (n = send( sockfd, buffer, len,0 ) ) == SOCKET_ERROR )
  #else
  if ( (n = write( sockfd, buffer, len) ) < 0 )
  #endif
  {
  	// disconnected or other error
  	
  }
   
  return n;
}

/*--------------------------------------------------------------------*/
/*!
 *  Get data from network
 *
 * \param msg message string to add
 *
 * \return number of byte, or SOCKET_ERROR
 *         
 *
 */
int getData( int sockfd,char *buffer,int len) {
  int n;
  #ifdef WIN32
  	if ( (n = recv(sockfd,buffer,len,0) ) == SOCKET_ERROR ) 
  #else
  	if ( (n = read(sockfd,buffer,len) ) < 0 )
  #endif
  	{
  		// disconnected or other error
  	}  
   else    
  	buffer[n] = '\0';
  
  return n;
}

/*--------------------------------------------------------------------*/
/*!
 *  Format errno message
 *
 * \param msg message string to add
 *
 * \return a standard error code. See errno.h
 *         
 *
 */
int handle_error(const char *msg)
{
	LPVOID lpMsgBuf;
	int e;

	lpMsgBuf = (LPVOID)"Unknown error";
	e = WSAGetLastError();
	if (FormatMessage(
			FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL, e,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_NEUTRAL),
				// Default language
			(LPTSTR)&lpMsgBuf, 0, NULL)) {
		fprintf(stderr, "%s: Error %d: %s\n", msg, e, lpMsgBuf);
		LocalFree(lpMsgBuf);
	} else
		fprintf(stderr, "%s: Error %d\n", msg, e);
		
		return e;
}


/*--------------------------------------------------------------------*/
/*!
 * Drive the robot with the keyboard
 *
 * \param none
 *
 * \return an error code:
 *         - <0  standard error code. See errno.h
 *         - >=0 on success
 *
 */
int drive_robot(int socketfd)
{
	int out=0,anymove=0;
	int ch;

	char chbuff[SOCKET_MAX_SIZE+1];
	
	clrscr(); // erase screen
	
	printf("Drive the robot with the keyboard:\n\n  's' or 'space'              : stop robot\n  arrows (UP,DOWN,LEFT,RIGHT) : control robot direction\n  e                           : toggle read motors L&R encoders\n  v                           : toggle read motors L&R speed \n\n  Home/End                    : pan left/right\n  Insert/Delete               : tilt up/down\n  Backspace or 'z'            : stop pan/tilt\n\n  PAGE UP/DOWN                : neck left/right\n  'c'                         : roll neck to center\n  'a'                         : roll neck to leftmost position \n\n  'q'                         : going back to main menu\n");
	
	
	
	// loop until 'q' is pushed
	while(!out)
	{
		if(_kbhit()) {
			ch=_getch ();
			if (ch == 0x0 || ch == 0xe0) {
				// get special keys
		    switch (ch=_getch ())
		    {	  
					case 72: // UP arrow = forward
							
						sprintf(chbuff,"f");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
				    {
				    	perror( const_cast<char *>("ERROR, sending up") );
				    }
							
						anymove=1;						
					break;
					case 80: // DOWN arrow = backward			
						anymove=1;
						
						sprintf(chbuff,"b");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
				    {
				    	perror( const_cast<char *>("ERROR, sending back") );
				    }
					break;
		
					case 0x4b: // LEFT arrow = left
						sprintf(chbuff,"l");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
					    {
					    	perror( const_cast<char *>("ERROR, sending left") );
					    }
							anymove=1;	
					break;
		
					case 0x4d: // RIGHT arrow = right
		
						sprintf(chbuff,"r");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
					    {
					    	perror( const_cast<char *>("ERROR, sending right") );
					    }
							anymove=1;	
					break;
	
					case 73: // PAGE UP  = neck up
				 			sprintf(chbuff,"u");
							if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
					    {
					    	perror( const_cast<char *>("ERROR, sending neck up") );
					    }
				 		anymove=1;
					break;
	
					case 81: // PAGE DOWN = neck down

			 			sprintf(chbuff,"d");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
					    {
					    	perror( const_cast<char *>("ERROR, sending neck down") );
					    }
				 		anymove=1;
					break;
			
					case 71: // Home  = pan left
				 		sprintf(chbuff,"pl");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
				    {
				    	perror( const_cast<char *>("ERROR, sending pan left") );
				    }
				 		anymove=1;
					break;
		
					case 79: // End = pan right
				 		sprintf(chbuff,"pr");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
				    {
				    	perror( const_cast<char *>("ERROR, sending pan right") );
				    }

				 		anymove=1;
					break;
					
					case 82: // Insert = tilt up
				 		sprintf(chbuff,"tu");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
				    {
				    	perror( const_cast<char *>("ERROR, sending tilt up") );
				    }

				 		anymove=1;
					break;
					
					case 83: //Delete = tilt down
				 		sprintf(chbuff,"td");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
				    {
				    	perror( const_cast<char *>("ERROR, sending tilt down") );
				    }

				 		anymove=1;
					break;
					
					default:
							printf ("\nYou hit special key '%c' %d 0x%x \n", ch,ch,ch);
					break	;	

				} // switch
							
				
			} // if (ch == 0 || ch == 224)	 
			else 
			{
				switch(ch)
				{
				 	case 'q': // quit to main menu
				 		out=1;
				   	break;
				  case ' ': // stop motor	
					case 's': 
							sprintf(chbuff,"s");
							if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
					    {
					    	perror( const_cast<char *>("ERROR, sending stop") );
					    }
							anymove=1;	
					break;
				  
					case 8: // backspace => stop pan/tilt
							sprintf(chbuff,"z");
							if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
					    {
					    	perror( const_cast<char *>("ERROR, sending stop pan/tilt") );
					    }
						break;
					 
					case 'a': // neck goes to defined angle
							sprintf(chbuff,"a");
							if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
					    {
					    	perror( const_cast<char *>("ERROR, sending neck angle") );
					    }
					
                        break;
							
					case 'c': // neck goes center
							sprintf(chbuff,"c");
							if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
					    {
					    	perror( const_cast<char *>("ERROR, sending neck center") );
					    }
						break;	
					
				
					case 'e': //read encoders
					sprintf(chbuff,"e");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
				    {
				    	perror( const_cast<char *>("ERROR, sending read encoders") );
				    }
					break;	
					
					case 'v': //read speed
					sprintf(chbuff,"v");
						if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
				    {
				    	perror( const_cast<char *>("ERROR, sending read speed") );
				    }
					break;	
						
				 	default:
				 			printf ("\nYou hit '%c' %d 0x%x \n", ch,ch,ch);
				   break;
				}
		  }
		  

		} else
		{
		

				
		}
		
		//usleep(100);
		
		// getting any answer
		int err=getData( sockfd,chbuff,SOCKET_MAX_SIZE);
	  int werr=WSAGetLastError(); //handle_error("Server not launched");
	  if ((err== SOCKET_ERROR) && (werr!=WSAEWOULDBLOCK))
	  {
	  	if (connected){
	  		handle_error("ERROR drive, receive: Disconnected?!");
	  		connected=0;
	  	} else
	  	{
	     	closesocket( sockfd );
		
				//Sleep(500);
				printf(".");
				if ( ( sockfd = socket(AF_INET, SOCK_STREAM, 0) ) < 0 ) {
		     	handle_error("ERROR opening socket");
		     	break;
				}
				 if ( connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) != 0) {
				  	//handle_error("ERROR: Could not reconnected\n");
				  	
				  	connected=0;

				  					    
				  } else
				  {
				  	printf("\nReconnected\n");
				  	connected=1;
				  }
				
					#ifdef WIN32
					// If iMode!=0, non-blocking mode is enabled.
					u_long iMode=1;
					if (ioctlsocket(sockfd,FIONBIO,&iMode)!= NO_ERROR) {
						handle_error("ERROR enabling non-blocking mode to socket");	
				    exit(-1);
					}
				 	
					#else	
					int flags = fcntl(sockfd, F_GETFL, 0);
				 	if (flags < 0) 	{
				 		perror( const_cast<char *>( "ERROR getting socket mode") );
				 		exit(-1);
					}
				 	flags =  flags|O_NONBLOCK;
				 	if (fcntl(sockfd, F_SETFL, flags) == 0)	{
				 		perror( const_cast<char *>( "ERROR enabling non-blocking mode to socket") );
				 		exit(-1);
					}
				 	
					#endif
			}
			
	 		
		} else if (werr!=WSAEWOULDBLOCK) {
			if (err>0)
			{
				
				// processing data
				gotoxy(0,20);
				printf("received ( %2d bytes): %s               ",strlen(chbuff),chbuff);
							
			} else
				{  // disconnected
					if (connected)
					{

					  connected =0;
					  
					  // trying to reconnect
						printf("Trying to reconnect...");
			   } else
			     {
			     	closesocket( sockfd );
				
						Sleep(500);
						printf(".");
						if ( ( sockfd = socket(AF_INET, SOCK_STREAM, 0) ) < 0 ) {
				     	handle_error("ERROR opening socket");
				     	break;
						}
						 if ( connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) != 0) {
						  	//handle_error("ERROR: Could not reconnected\n");
						  	
						  	connected=0;
	
						  					    
						  } else
						  {
						  	printf("\nReconnected\n");
						  	connected=1;
						  }
						
							#ifdef WIN32
							// If iMode!=0, non-blocking mode is enabled.
							u_long iMode=1;
							if (ioctlsocket(sockfd,FIONBIO,&iMode)!= NO_ERROR) {
								handle_error("ERROR enabling non-blocking mode to socket");	
						    exit(-1);
							}
						 	
							#else	
							int flags = fcntl(sockfd, F_GETFL, 0);
						 	if (flags < 0) 	{
						 		perror( const_cast<char *>( "ERROR getting socket mode") );
						 		exit(-1);
							}
						 	flags =  flags|O_NONBLOCK;
						 	if (fcntl(sockfd, F_SETFL, flags) == 0)	{
						 		perror( const_cast<char *>( "ERROR enabling non-blocking mode to socket") );
						 		exit(-1);
							}
						 	
							#endif
					}
					
				}
		} else{
			  // connected, no data

		}

		usleep(1000);
		
		// wait some ms
	} // while

	//kb_change_term_mode(0); // switch to normal key input mode	
	//kh4_set_speed(0,0,dsPic );	 
	
	// stop robot
	sprintf(chbuff,"s");
	if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
  {
  	handle_error("ERROR, sending stop");
  }
	
	
	
	clrscr();
	return 0;
}



/*--------------------------------------------------------------------*/
/*!
 * Print the main menu
 *
 *
 */
void print_main_menu() {
		printf("\nChoose an option: enter (letter) then [its argument(s)], then push ENTER:\n\n");
		
		printf("  (d)rive mode (parameters must be set before)\n");
		printf("  re(i)nit neck\n");
		printf("  (s)top motor\n");
		printf("  (p [MOT] [PARAM] [VALUE]) set parameter: MOT is l=left r=right n=neck o=none\n     [PARAM]: PORT LED_GPIO I2C KP KI KD ACC_INC ACC_DIV MIN_SPEED POS_MARG\n              SPEED_POS CONTROL SPEED PWM POS ACT_POS NOM_SPEED NOM_PWM\n              NOM_ANGLE PAN_NOM_SPEED TILT_NOM_SPEED PULSES_DEG PULSES_MM\n              GOAL_X GOAL_Y GOAL_A\n");
		printf("  (g [MOT] [PARAM]) get parameter: MOT is l=left, r=right, n=neck o=none\n     [PARAM]: PORT LED_GPIO I2C REV KP KI KD ACC_INC ACC_DIV MIN_SPEED POS_MARG\n              SPEED_POS CONTROL SPEED POS PWM ACT_SPEED ACT_CURRENT ACT_POS\n              ON_TRGT SW1 SW2 NOM_PWM NOM_SPEED NOM_ANGLE PAN_NOM_SPEED\n              TILT_NOM_SPEED PULSES_DEG PULSES_MM\n              GOAL_X GOAL_Y GOAL_A\n");
		printf("  (sa)ve all used parameters (saved normally at exit of the server program)\n");
		printf("  (sh)ut down robot\n");
		printf("  (r)econnect to server\n");
		printf("  (q)uit program\n");
		
		printf("\noption:                 ");
}


/*--------------------------------------------------------------------*/
/*------------ MAIN --------------------------------------------------*/
/*!
 *  Main program
 *
 * \param argc argument number
 *				argv arguments array 
 *
 * \return 0 no error
 *					<0 error
 *         
 *
 */
int main(int argc, char *argv[])
{
	int portno = DEFAULT_SERVER_PORT, n,werr;
	char serverIp[16] = DEFAULT_SERVER_IP;
	struct hostent *server;
	u_long iMode;
	char buffer[256], chbuff[SOCKET_MAX_SIZE+1];
	
	#define  LINE_LEN 80
	char line[LINE_LEN+1]; // line for getting user input
	
	
	if (argc != 3) {
	  printf("Using default server ip %s on port %d.\n", serverIp, portno );
	  // exit(0);
	} else 
	{
		if (sprintf(serverIp,"%s",argv[1])<=0) {
			printf("ERROR in serverIp = %s ; exiting\n!",argv[1]);
			printf("\nPush RETURN to exit!\n\n");
			fflush(stdout);
			char c = getc(stdin);
			exit(-1);
		}
		
	
		
		if (sscanf(argv[2],"%d",&portno)!=1) {
			printf("ERROR in port number : %s ; exiting\n!",argv[2]);
			printf("\nPush RETURN to exit!\n\n");
			fflush(stdout);
			char c = getc(stdin);
			exit(-2);
		}
		
		
	}
	
	printf( "Contacting %s on port %d:\n", serverIp, portno );

	#ifdef WIN32
	WSADATA wsaData;
  if (  WSAStartup(0x0202, &wsaData) != 0	)  {
		  /* La fonction WSAStartup a echoue */ ;	
		handle_error("ERROR WSAStartup");
		WSACleanup();
		printf("\nPush RETURN to exit!\n\n");
		fflush(stdout);
		char c = getc(stdin);
		exit(-3);
	}	
	#endif
	
  if ( ( sockfd = socket(AF_INET, SOCK_STREAM, 0) ) < 0 ) {
		handle_error("ERROR opening socket");
		WSACleanup();
		printf("\nPush RETURN to exit!\n\n");
		fflush(stdout);
		char c = getc(stdin);
	  exit(-4);
	}

  if ( ( server = gethostbyname( serverIp ) ) == NULL ) {
    handle_error("ERROR, no such host\n");
    WSACleanup();
    printf("\nPush RETURN to exit!\n\n");
		fflush(stdout);
		char c = getc(stdin);
  	exit(-5);
	}    
 
  bzero( (char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  bcopy( (char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
  serv_addr.sin_port = htons(portno);
  
  if ( connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) != 0) {
  	handle_error("Server not launched");
		connected=0;   
		/*
		  	WSACleanup();
		gotoxy(0,20);
		printf("\nPush RETURN to exit!\n\n");
		
		// wait
		fflush(stdout);
		char c = getc(stdin);
		exit(-1);*/   
  } else
  {
  	printf("Connected\n");
  	connected=1;
  	
  		#ifdef WIN32
			// If iMode!=0, non-blocking mode is enabled.
			iMode=1;
			if (ioctlsocket(sockfd,FIONBIO,&iMode)!= NO_ERROR) {
				handle_error("ERROR enabling non-blocking mode to socket");	
		    exit(-6);
		    printf("\nPush RETURN to exit!\n\n");
				fflush(stdout);
				char c = getc(stdin);
			}
		 	
			#else	
			int flags = fcntl(sockfd, F_GETFL, 0);
		 	if (flags < 0) 	{
		 		perror( const_cast<char *>( "ERROR getting socket mode") );
		 		exit(-1);
			}
		 	flags =  flags|O_NONBLOCK;
		 	if (fcntl(sockfd, F_SETFL, flags) == 0)	{
		 		perror( const_cast<char *>( "ERROR enabling non-blocking mode to socket") );
		 		exit(-1);
			}
		 	
			#endif
  }


	// menu and process loop
	while (quitReq==0) {
	
		//gotoxy(0,0);
		
		// print menu
		print_main_menu();
 		gotox(8);
		
		fflush(stdout);
		usleep(200000);
		
		// wait and save choice
		fgets(line,LINE_LEN,stdin);
		//clrscr();
		
		// remove newline character
		if (strlen(line)>0)
			line[strlen(line)-1]='\0';
		
		// applay selected choice
		switch(line[0]) {
			
			case 'd': // drive mode
				drive_robot(sockfd);
			break;
			
			
			case 'i': // init neck
					printf("Initialising neck!\n");	
					sprintf(chbuff,"i");
					if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
			    {
			    	handle_error("ERROR, sending init neck");
			    }
			break;
			
			case 'q': // quit
				quitReq=1;
				break;
				

			case 'g': // get parameter
			if (strlen(line)>2)
			{
				printf("Getting parameter: %s\n",line+2);	
				strncpy(chbuff,line,SOCKET_MAX_SIZE);
				chbuff[SOCKET_MAX_SIZE]='\0';
				if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
		    {
		    	handle_error("ERROR, sending Getting parameter");
		    }
			} else
			{
				printf("\n*** ERROR ***: option '%c' as no parameter!\n\n",line[0]);	
			}
			break;
						
			case 'p': // set parameter
				if (strlen(line)>2)
				{
					printf("Setting parameter: %s\n",line+2);	
					strncpy(chbuff,line,SOCKET_MAX_SIZE);
					chbuff[SOCKET_MAX_SIZE]='\0';
					if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR) {
			    	handle_error("ERROR, sending Setting parameter");
			    }
					} else
					{
						printf("\n*** ERROR ***: option '%c' as no parameter!\n\n",line[0]);	
					}
					break;
			
			
			case 'r': // reconnect to server
				closesocket( sockfd );
				
				//Sleep(500);
				if ( ( sockfd = socket(AF_INET, SOCK_STREAM, 0) ) < 0 ) {
		     	handle_error("ERROR opening socket");
		     	break;
				}
				 if ( connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) != 0) {
				  {
				  	handle_error("ERROR: Could not reconnected to socket");
				  	
				  	connected=0;
				  	break;
				  }					    
				  } else
				  {
				  	printf("\nReconnected\n");
				  	connected=1;
				  }
				
					#ifdef WIN32
					// If iMode!=0, non-blocking mode is enabled.
					iMode=1;
					if (ioctlsocket(sockfd,FIONBIO,&iMode)!= NO_ERROR) {
						handle_error("ERROR enabling non-blocking mode to socket");	
				    exit(-1);
					}
				 	
					#else	
					int flags = fcntl(sockfd, F_GETFL, 0);
				 	if (flags < 0) 	{
				 		perror( const_cast<char *>( "ERROR getting socket mode") );
				 		exit(-1);
					}
				 	flags =  flags|O_NONBLOCK;
				 	if (fcntl(sockfd, F_SETFL, flags) == 0)	{
				 		perror( const_cast<char *>( "ERROR enabling non-blocking mode to socket") );
				 		exit(-1);
					}
				 	
					#endif
			break;
					
			case 's': // save param, stop, shutdown
				if ((strlen(line)>1 && (line[1]=='h')))	{ // shutdown
					printf("Shutting down robot!\n");	
					sprintf(chbuff,"sh");
					if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
			    {
			    	handle_error("ERROR, sending shutdown");
			    }
				} else 
					if ((strlen(line)>1 && (line[1]=='a')))	{ //save param
					printf("Saving parameters!\n");	
					sprintf(chbuff,"sa");
					if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
			    {
			    	handle_error("ERROR, saving parameters");
			    }
				} else 
				if (strlen(line)==1) { // stop
					printf("Stopping the robot!\n");
					
					sprintf(chbuff,"s");

					if(sendData(sockfd,chbuff,strlen(chbuff))== SOCKET_ERROR)
			    {
			    	werr=WSAGetLastError();
			    	printf("ERROR, sending stop (WSA:%d)%s\n",werr,werr==WSAENOTCONN?": disconnected!":(werr==WSAECONNABORTED?": server disconnected!":"") );
			    }	
				} else {
					printf("\n*** ERROR ***: option '%s' is undefined!\n\n",line);	
				}
				break;		

				
			default: printf("\n*** ERROR ***: option '%c' (0x%02x) is undefined!\n\n",line[0],line[0]);		
		}	
	 
	 	usleep(100000); // TO DO: DECREASE DELAY
	
		// getting any answer
		int err=getData( sockfd,chbuff,SOCKET_MAX_SIZE);
	  int werr=WSAGetLastError(); 
	  if ((err== SOCKET_ERROR) && (werr!=WSAEWOULDBLOCK))
	  {
	  	
	  	if (connected)
	  	{
				printf("ERROR, receive; Disconnected ?!\n");
				connected=0;
			}
	 		
		} else if (werr!=WSAEWOULDBLOCK) {
			if (err>0)
			{

				// processing answer
				//gotoxy(0,15);
				printf("\nreceived ( %2d bytes): %s     \n",strlen(chbuff),chbuff);
	
				
				
				
			} else
			{
				#ifdef DEBUG
				printf("DEBUG: getData err: %d (WSA: %d)\n",err,werr);
				#endif
			}
		} else
		{
			// connected, no data
		}
	} // while(quitReq==0)
	

  closesocket( sockfd );
	
	#ifdef WIN32
	WSACleanup();
	#endif
	
	// wait
	/*gotoxy(0,20);
	printf("\nPush RETURN to exit!\n\n");
	fflush(stdout);
	char c = getc(stdin);*/
	
  return 0;
}
