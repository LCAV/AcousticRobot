echo -e '\E[37;44m'"\033[1mStarting server\033[0m"
sleep 5
date
#echo 18 > /sys/class/gpio/export
#echo out > /sys/class/gpio/gpio18/direction
#echo 1 > /sys/class/gpio/gpio18/value
/root/server
#echo 0 > /sys/class/gpio/gpio18/value
#echo 18 > /sys/class/gpio/unexport
exit 0
