//--------------------------------------------------------------------------------//
//-                   KJ_EVO ( K-Junior extension board			 )                     -//
//                                                                               -//
//-  Copyright (C) Julien Tharin, K-Team S.A. 2011                               -//
//-  This library is free software; you can redistribute it and/or               -//
//-  modify it under the terms of the GNU Lesser General Public                  -//
//-  License as published by the Free Software Foundation; either                -//
//-  version 2.1 of the License, or any later version.                           -//
//-                                                                              -//
//-  This library is distributed in the hope that it will be useful,             -//
//-  but WITHOUT ANY WARRANTY; without even the implied warranty of              -//
//-  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU           -//
//-  Lesser General Public License for more details.                             -//
//-                                                                              -//
//-  You should have received a copy of the GNU Lesser General Public            -//
//-  License along with this library; if not, write to the Free Software         -//
//-  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   -//
//-                                                                              -//
//-                               __  __  ________                               -//
//- K-Team S.A.                  |  |/  /|__    __|___  _____  ___  ___          -//
//- Rue Galilee 9. Y-Park,       |     / __ |  | _____|/  _  \|   \/   |         -//
//- 1400 Yverdon-les-Bains       |  |  \    |  | ____|/  /_\  |        |         -//
//- Switzerland                  |__|\__\   |__|______|_/   \_|__|\/|__|         -//
//- jtharin@k-team.com   tel:+41 24 423 89 75 fax:+41 24 423 8960                -//
//-                                                                              -//
//--------------------------------------------------------------------------------//

////////////////////////////////////////////////////////////////////////////////
/*!   \file i2c.c
      \brief Functions for using the i2c of the K-Junior extension board
*/
////////////////////////////////////////////////////////////////////////////////

#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>



#include <errno.h>
#include <stdlib.h>
#include <stdio.h>

#include "i2c-dev.h"
#include "i2c.h"


static int fh=-1; // file handler

static char dev_address;

int i2c_already_open=0;


/*---- Internal Functions ---------------------------------------------*/

/*---------------------------------------------------------------------*/
/*!
 * This function selects an I²C Device on a given I²C Bus.
 *
 * \return an error code
 *         - <0 standard error code. See errno.h
 *         - 0 on success
 *
 * \remarks This function is used internally and is never
 *          exported outside this module.
 */
int i2c_priv_select_device(char address)
{
  int rc;

  /* change device only if necessary */
  if (dev_address != address ) {

    if ((rc=ioctl( fh , I2C_SLAVE , address )) < 0)
      return rc;

    dev_address = address;
  }
  return 0;
}

/*---- Public Functions ----------------------------------------------*/


/*--------------------------------------------------------------------*/
/*!
 * This function opens an I²C Bus. It is called by kj_evo_init().
 *
 * \param none
 * \return an error code
 *          - <0 standard error number. See errno.h
 *          - 0 if I²C Bus Device has been opened
 */
int i2c_open()
{
	if ((fh = open(I2C_DEV, O_RDWR)) <0)
	{
		
		return fh;
	}
	
	i2c_already_open=1;

	return 0;
}



/*--------------------------------------------------------------------*/
/*!
 * This procedure closes an I²C Bus. It is called by kj_evo_exit().
 *
 */
void i2c_close()
{
 close(fh);
 i2c_already_open=0;
}



/*--------------------------------------------------------------------*/
/*!
 * This function is the primitive to read data from a given device
 * on a given I²C Bus.
 *
 * \param dev_address device address to write to
 * \param reg_address address of the register to read from
 * \param buf Pointer to the buffer that will receive the data bytes.
 * \param len Size of the buffer in bytes.
 * \return an error code:
 *         - <0 standard error number. See errno.h
 *         - >=0 number of bytes read
 */
int i2c_read(char dev_address,char reg_address,
		char * buf ,
		unsigned int len )
{
  int rc;

  
  rc=i2c_transfer(dev_address,&reg_address,1,buf,len);
 
  //rc=i2c_smbus_read_i2c_block_data(fh,reg_address,len,buf);
 

  return rc;
}

/*--------------------------------------------------------------------*/
/*!
 * This function is the primitive to write data to a given device
 * on a given I²C Bus.
 *
 * \param dev_address device address to write to
 * \param reg_address address of the register to write to
 * \param buf Pointer to the buffer that will be written.
 * \param len Number of bytes to write
 * \return an error code:
 *         - <0 standard error number. See errno.h
 *         - >=0 number of bytes written
 */
int i2c_write(char dev_address,char reg_address,
		 const char * buf ,
		 unsigned int len )
{
  int rc;
  int i;
  char *bufreg;
  
  i2c_priv_select_device(dev_address);
 

	// add reg address
	len+=1; 
	
  bufreg=(char*)malloc(sizeof(char)*len);

  if (bufreg==NULL)
	return -ENOMEM;
	
	bufreg[0]=reg_address;

	for (i=1;i<len;i++)
		bufreg[i]=buf[i-1];

  rc = write( fh , bufreg , len );

	free(bufreg);
	

	

	//rc=i2c_smbus_write_i2c_block_data(fh,reg_address,len,buf);

  return rc;
}

/*--------------------------------------------------------------------*/
/*!
 *
 * This function is the primitive to write data to and then read
 * data from a given device on a given I²C Bus.
 *
 * Normally an end user don't want to use these function as they are
 * assumed as "low level functions".
 *
 * \param dev       I²C Device Address. This value contains only
 *                  the I²C address bits (7-bit or 10-bit).
 * \param write_buf Pointer to the buffer that contains the data
 *                  to be written.
 * \param write_len Number of bytes to write. The data are in
 *                  the write buffer.
 * \param read_buf  Pointer to the buffer that will receive the
 *                  data.
 * \param read_len  Size of the read buffer in bytes.
 * \return an error code:
 *         - <0  standard error code. See errno.h
 *         - >=0 on success
 */
int i2c_transfer(  char dev ,
		    const char * write_buf , unsigned int write_len ,
		    char * read_buf , unsigned int read_len )
{
  struct i2c_msg             msgs[2];
  struct i2c_rdwr_ioctl_data msgset;
  int rc;

  /* Write Message */
  msgs[0].addr  = dev;
  msgs[0].flags = 0;
  msgs[0].buf   = (char *)write_buf;
  msgs[0].len   = write_len;

  /* Read Message */
  msgs[1].addr  = dev;
  msgs[1].flags = I2C_M_RD;
  msgs[1].buf   = read_buf;
  msgs[1].len   = read_len;

  msgset.msgs  = msgs;
  msgset.nmsgs = 2;

  rc = ioctl(  fh , I2C_RDWR , &msgset );

  return rc;
}



/*--------------------------------------------------------------------*/
/*!
 * This function verifies the existance of a given device on
 * a given I²C Bus.
 *

 * \param dev  I²C Device Address. This value contains only
 *             the I²C address bits (7-bit or 10-bit).
 *
 * \return A value indicating if a device is present or not:
 *         - 1 device present
 *         - 0 no device present
 */
int i2c_exists( char dev )
{
  int rc;
 /* struct i2c_msg msg;
  struct i2c_rdwr_ioctl_data msgset;
 
  msg.addr  = dev;
  msg.flags = 0;
  msg.buf   = 0;
  msg.len   = 0;
    
  msgset.msgs  = &msg;
  msgset.nmsgs = 1;

  rc = ioctl( i2c->fd , I2C_RDWR , &msgset ); */
  
  //printf("\nDEBUG: function: %s  fd: %d  addr: %d\n\n",__FUNCTION__,i2c->fd,dev);
  
  ioctl(fh,I2C_SLAVE,dev);
  rc=i2c_smbus_read_byte(fh);
  
  /* answer from an I²C device */ 
  if ( rc >= 0 ) return 1;
  //if ( rc == 1 ) return 1;

  return 0;
}

/*--------------------------------------------------------------------*/
/*!
 * This function scans a given I²C Bus to find devices
 *
 * \param callback  A callback function called when a device is found.
 *                  If this callback function returns a value <0 the
 *                  bus scan stops immedialety and the value is
 *                  used as return value by i2c_scan.
 * \param context   A value or a pointer passed to the callback
 *                  function.
 * \return an error code:
 *         - <0 standard error code (See errno.h) or a user error code.
 *         - >=0 Number of devices found on the I²C bus.
 */
int i2c_scan(
	      int (*callback)(
			       char adr ,
			       void * context ) ,
	      void * context)
{
  int rc, adr, found=0;
 

  /* scan the whole I²C bus range */
  for (adr=2; adr<128; adr++) {
    ioctl(fh,I2C_SLAVE,adr);
   	rc=i2c_smbus_read_byte(fh);
    
    /* answer from a I²C device */
    
    if ( rc >= 0 ) {
      found++;
      if ( callback != NULL ) {
				if ((rc=callback(  adr , context ))<0)
	  			return rc;
      }
    }
    
  }

  return found;
}



