/* 
		PAH
		Julien Tharin, 2014
		The server waits for a socket connection request from a client.
		It can be stopped properly by sending SIGINT signal (-2)
 
        Modified by Frederike Duembgen, November 2015:
        changed stop_drive_motors for motors to shut down instead of setting speed to zero.

*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <termios.h>
#include <sys/time.h>
#include <math.h>

// for adapting C headers to C++
#ifdef __cplusplus
extern "C" {
#endif
#include "i2c.h"

#ifdef __cplusplus
}
#endif	

// if defined, debug printing are done
//#define DEBUG 1



/*----------------------- DEFINE -------------------------------------*/
/*--------------------------------------------------------------------*/

// Default values

#define DEFAULT_LEFT_MOTOR_I2C_ADDRESS  0x20
#define DEFAULT_RIGHT_MOTOR_I2C_ADDRESS 0x21
#define DEFAULT_NECK_MOTOR_I2C_ADDRESS  0x22
#define DEFAULT_LED_GPIO_NB 18


#define SOCKET_MAX_SIZE 31 // socket read/write buffer size

#define DEFAULT_SERVER_PORT 51717

#define RS485_DEVICE "/dev/ttyRPC0"
#define RS485_SPEED B2400

#define NECK_SW1_SW2_RANGE_ANGLE 18 // angle between sw1 and sw2


// Pelco D settings
#define RS485_PELCOD_CMD_SIZE 7 // pelco D size
#define PAN_TILT_PELCOD_ADDRESS 1 // address of pan/tilt device
#define PAN_TILT_PELCOD_COMMAND_2_TILT_DOWN 16
#define PAN_TILT_PELCOD_COMMAND_2_TILT_UP 8
#define PAN_TILT_PELCOD_COMMAND_2_PAN_LEFT 4
#define PAN_TILT_PELCOD_COMMAND_2_PAN_RIGHT 2

#define SETTINGS_FILENAME "settings.txt"

#define REG_REV 0x10
#define REG_KP 0x11
#define REG_KI 0x12
#define REG_KD 0x13
#define REG_MOT_ACC_INC 0x14
#define REG_MOT_ACC_DIV 0x15
#define REG_MOT_MIN_SPEED 0x16
#define REG_MOT_POS_MARG 0x17  // on 2 bytes
#define REG_MOT_SPEED_POS 0x19 // on 2 bytes
#define REG_MOT_CONTROL 0x1B
#define REG_MOT_SPEED 0x1C // on 2 bytes
#define REG_MOT_PWM 0x1E // on 2 bytes
#define REG_MOT_POS 0x20 // on 4 bytes
#define REG_ACT_SPEED 0x24 // on 2 bytes
#define REG_ACT_CURRENT 0x26 // on 2 bytes
#define REG_ACT_POS 0x28 // on 4 bytes
#define REG_MOT_ON_TRGT 0x2C
#define REG_SW1 0x2D
#define REG_SW2 0x2E

#define AUTO_TIME 500000 // time to send automatically data

#define NECK_SAFE_TIMER  2000 // Safe timer to exit if no Switch detected by the Roll

enum Mot_control {eCTRL_IDLE=0,eCTRL_SPEED=1,eCTRL_SPEED_ACC=2,eCTRL_POSITION=3,eCTRL_OPEN_LOOP=4};


// -----   for config file 
// setting name for config file
const char *settings_name[]={"PORT","LED_GPIO","LEFT_I2C","LEFT_NOM_SPEED","LEFT_KP","LEFT_KI","LEFT_KD","LEFT_ACC_INC",\
"LEFT_ACC_DIV","LEFT_MIN_SPEED","LEFT_POS_MARG","LEFT_SPEED_POS",\
"RIGHT_I2C","RIGHT_NOM_SPEED","RIGHT_KP","RIGHT_KI","RIGHT_KD","RIGHT_ACC_INC","RIGHT_ACC_DIV","RIGHT_MIN_SPEED","RIGHT_POS_MARG","RIGHT_SPEED_POS",\
"NECK_I2C","NECK_NOM_PWM","NECK_NOM_ANGLE","NECK_KP","NECK_KI","NECK_KD","NECK_ACC_INC","NECK_ACC_DIV","NECK_MIN_SPEED","NECK_POS_MARG","NECK_SPEED_POS","PAN_NOM_SPEED","TILT_NOM_SPEED","LEFT_PULSES_DEG","LEFT_PULSES_MM","RIGHT_PULSES_DEG","RIGHT_PULSES_MM","GOAL_X","GOAL_Y","GOAL_A"};

// setting print type
const char *settings_scantype[]={"%d","%d","%x","%d","%d","%d","%d","%d",\
"%d","%d","%d","%d",\
"%x","%d","%d","%d","%d","%d","%d","%d","%d","%d",\
"%x","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d"};

// setting scan type
const char *settings_printtype[]={"%d","%d","0x%x","%d","%d","%d","%d","%d",\
"%d","%d","%d","%d",\
"0x%x","%d","%d","%d","%d","%d","%d","%d","%d","%d",\
"0x%x","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d"};

// setting enum access name
enum  Enum_settings {ePORT=0,eLED_GPIO,eLEFT_I2C,eLEFT_NOM_SPEED,eLEFT_KP,eLEFT_KI,eLEFT_KD,eLEFT_ACC_INC,\
eLEFT_ACC_DIV,eLEFT_MIN_SPEED,eLEFT_POS_MARG,eLEFT_SPEED_POS,\
eRIGHT_I2C,eRIGHT_NOM_SPEED,eRIGHT_KP,eRIGHT_KI,RIGHT_KD,eRIGHT_ACC_INC,eRIGHT_ACC_DIV,eRIGHT_MIN_SPEED,eRIGHT_POS_MARG,eRIGHT_SPEED_POS,\
eNECK_I2C,eNECK_NOM_PWM,eNECK_NOM_ANGLE,eNECK_KP,eNECK_KI,NECK_KD,eNECK_ACC_INC,eNECK_ACC_DIV,eNECK_MIN_SPEED,eNECK_POS_MARG,eNECK_SPEED_POS,ePAN_NOM_SPEED,eTILT_NOM_SPEED,eLEFT_PULSES_DEG,eLEFT_PULSES_MM,eRIGHT_PULSES_DEG,eRIGHT_PULSES_MM,eGOAL_X,eGOAL_Y,eGOAL_A};

// setting i2c byte size: 0= not i2c, 1= one byte, 2= 2 bytes
int settings_i2csize[]={0,0,0,0,1,1,1,1,\
1,1,2,2,\
0,0,1,1,1,1,1,1,2,2,\
0,0,0,1,1,1,1,1,1,2,2,0,0,0,0,0,0,0,0,0}; 

// setting i2c registers: -1= not i2c, other : reg
int settings_i2creg[]={-1,-1,-1,-1,REG_KP,REG_KI,REG_KD,REG_MOT_ACC_INC,\
REG_MOT_ACC_DIV,REG_MOT_MIN_SPEED,REG_MOT_POS_MARG,REG_MOT_SPEED_POS,\
-1,-1,REG_KP,REG_KI,REG_KD,REG_MOT_ACC_INC,REG_MOT_ACC_DIV,REG_MOT_MIN_SPEED,REG_MOT_POS_MARG,REG_MOT_SPEED_POS,\
-1,-1,-1,REG_KP,REG_KI,REG_KD,REG_MOT_ACC_INC,REG_MOT_ACC_DIV,REG_MOT_MIN_SPEED,REG_MOT_POS_MARG,REG_MOT_SPEED_POS,-1,-1,-1,-1,-1,-1,-1,-1,-1};


// setting  board type: -1	= global setting , 0 = left motor, 2= right motor 3= neck motor
int settings_board[]={-1,-1,0,0,0,0,0,0,\
0,0,0,0,\
1,1,1,1,1,1,1,1,1,1,\
2,2,2,2,2,2,2,2,2,2,2,-1,-1,0,0,1,1,-1,-1,-1}; 

#define eROT_SPEED 20


// number of settings
#define SETTINGS_NUMBER ( sizeof( settings_name ) / sizeof( *settings_name ) )  

int settings_value[SETTINGS_NUMBER]; // value of settings
int settings_used[SETTINGS_NUMBER]={0}; // array of settings currently used : 1 used, 0, not used;

//--------------------------------------------

// -----  variables  for running
// setting name for config file
const char *variables_name[]={"LEFT_REV","LEFT_CONTROL","LEFT_SPEED","LEFT_PWM","LEFT_POS",\
"LEFT_ACT_SPEED","LEFT_ACT_CURRENT","LEFT_ACT_POS","LEFT_ON_TRGT","LEFT_SW1","LEFT_SW2",\
"RIGHT_REV","RIGHT_CONTROL","RIGHT_SPEED","RIGHT_PWM","RIGHT_POS",\
"RIGHT_ACT_SPEED","RIGHT_ACT_CURRENT","RIGHT_ACT_POS","RIGHT_ON_TRGT","RIGHT_SW1","RIGHT_SW2",\
"NECK_REV","NECK_CONTROL","NECK_SPEED","NECK_PWM","NECK_POS",\
"NECK_ACT_SPEED","NECK_ACT_CURRENT","NECK_ACT_POS","NECK_ON_TRGT","NECK_SW1","NECK_SW2"
};

// setting print type
const char *variables_scantype[]={"%x","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d",\
"%x","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d",\
"%x","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d"};

// setting scan type
const char *variables_printtype[]={"0x%x","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d",\
"0x%x","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d",\
"0x%x","%d","%d","%d","%d","%d","%d","%d","%d","%d","%d"};

// setting enum access name
enum  Enum_variables {eLEFT_REV=0,eLEFT_CONTROL,eLEFT_SPEED,eLEFT_PWM,eLEFT_POS,eLEFT_ACT_SPEED,eLEFT_ACT_CURRENT,\
eLEFT_ACT_POS,eLEFT_ON_TRGT,eLEFT_SW1,eLEFT_SW2,eRIGHT_REV,eRIGHT_CONTROL,eRIGHT_SPEED,eRIGHT_PWM,eRIGHT_POS,eRIGHT_ACT_SPEED,eRIGHT_ACT_CURRENT,\
eRIGHT_ACT_POS,eRIGHT_ON_TRGT,eRIGHT_SW1,eRIGHT_SW2,eNECK_REV,eNECK_CONTROL,eNECK_SPEED,eNECK_PWM,eNECK_POS,eNECK_ACT_SPEED,eNECK_ACT_CURRENT,\
eNECK_ACT_POS,eNECK_ON_TRGT,eNECK_SW1,eNECK_SW2};

// setting i2c byte size: 0= not i2c, 1=one byte, 2=2 bytes, 4=4 bytes , LSB first
int variables_i2csize[]={1,1,2,2,4,2,2,4,1,1,1,1,1,2,2,4,2,2,4,1,1,1,1,1,2,2,4,2,2,4,1,1,1}; 

// max size of an i2c data
#define MAX_I2C_SIZE 4

// setting i2c registers: -1= not i2c, other : reg
int variables_i2creg[]={REG_REV,REG_MOT_CONTROL,REG_MOT_SPEED,REG_MOT_PWM,REG_MOT_POS,REG_ACT_SPEED,REG_ACT_CURRENT,\
REG_ACT_POS,REG_MOT_ON_TRGT,REG_SW1,REG_SW2,REG_REV,REG_MOT_CONTROL,REG_MOT_SPEED,REG_MOT_PWM,REG_MOT_POS,REG_ACT_SPEED,REG_ACT_CURRENT,\
REG_ACT_POS,REG_MOT_ON_TRGT,REG_SW1,REG_SW2,REG_REV,REG_MOT_CONTROL,REG_MOT_SPEED,REG_MOT_PWM,REG_MOT_POS,REG_ACT_SPEED,REG_ACT_CURRENT,\
REG_ACT_POS,REG_MOT_ON_TRGT,REG_SW1,REG_SW2};


// setting i2c board type: -1	= global setting , 0 = left motor, 2= right motor 3= neck motor
int variables_board[]={0,0,0,0,0,0,0,0,0,0,0,\
1,1,1,1,1,1,1,1,1,1,1,\
2,2,2,2,2,2,2,2,2,2,2	
}; 



// number of settings
#define VARIABLES_NUMBER ( sizeof( variables_name ) / sizeof( *variables_name ) )  

int variables_value[VARIABLES_NUMBER]; // value of variables


//----------------------------------------

int boards_i2c_addr[]={DEFAULT_LEFT_MOTOR_I2C_ADDRESS,DEFAULT_RIGHT_MOTOR_I2C_ADDRESS,DEFAULT_NECK_MOTOR_I2C_ADDRESS};
enum Enum_board {eLEFT_BOARD=0,eRIGHT_BOARD=1,eNECK_BOARD=2};
const char *boards_name[]={"LEFT","RIGHT","NECK"};

int led_gpio_nb=DEFAULT_LED_GPIO_NB;

// hack to test sizeof on compilation: if condition is true, the compilation gives error; if false, compilation succeed and no code remains
#define BUILD_BUG_ON(condition) ((void)sizeof(char[1 - 2*!!(condition)]))



/*----------------------- GLOBAL VARIABLES ---------------------------*/
/*--------------------------------------------------------------------*/
int newsockfd=-1; // socket file hander of connected client

int quitReq = 0;
int led_fh=-1; // LED file handler

int rs485_fd=-1; // rs485 file handler

int neck_sw1_sw2_range_time=-1; // time of move between switch 1 & 2 of neck [us]
int neck_current_time=-1; // current position of neck roll in time [us]
int neck_current_angle=0;

int mode_gotoxya=0;  // goto position mode

double goal_x=0,goal_y=0,goal_a=0; // position control goal
  
double current_a=0,current_x=0,current_y=0; // robot current position, angle

int auto_s=0; // send speed automatically
int auto_p=0; // send position automatically

/*----------------------- FUNCTIONS ----------------------------------*/
/*--------------------------------------------------------------------*/
/*!
 * Initialise given gpio
 *
 * \param gpio number
 *				input 1: input, 0 output
 *
 * \return 0 OK, <0 error
 */
static int init_gpio( int gpio, int input) 
{
		FILE* fh;
		char buffer[64];
		
		// export gpio
    if ( (fh = fopen("/sys/class/gpio/export", "w")) == NULL)
 		{
			return -errno;
		}
				
		if (fprintf(fh,"%d\n",gpio)<0)
		{
			return -errno;
		}
		fclose(fh);
		
		// set gpio direction
		sprintf(buffer,"/sys/class/gpio/gpio%d/direction",gpio);
		 if ( (fh = fopen(buffer, "w")) == NULL)
 		{
			return -errno;
		}
				
		if (fprintf(fh,"%s\n",input?"in":"out")<0)
		{
			return -errno;
		}
		fclose(fh);
		
		// unbuffered open gpio value file 
		sprintf(buffer,"/sys/class/gpio/gpio%d/value",gpio);
		 if ( (led_fh = open(buffer,  O_WRONLY)) < 0)
 		{
			return -errno;
		}
		
	return 0;
}



/*--------------------------------------------------------------------*/
/*!
 * Release gpio
 *
 * \param gpio number
 *
 * \return 0 OK, <0 error
 */
static int release_gpio( int gpio ) 
{
	FILE* fh;
	char buffer[64];
	
	// release file handler of led
  if (led_fh==-1)
	{	
		return -1;
	}
	
	close(led_fh);
	
	
	// unexport gpio
	if ( (fh = fopen("/sys/class/gpio/unexport", "w")) == NULL)
	{
		return -errno;
	}
			
	if (fprintf(fh,"%d\n",gpio)<0)
	{
		return -errno;
	}
	fclose(fh);
	
	return 0;
}


/*--------------------------------------------------------------------*/
/*!
 * Set gpio to 1
 *
 * \param gpio number
 *
 * \return 0 OK, <0 error
 */
static int set_gpio( int gpio ) 
{
	// release file handler of led
  if (led_fh==-1)
	{	
		return -1;
	}
	
	if (write(led_fh,"1",1)<0)
	{
		return -errno;
	};
	
	return 0;
}


/*--------------------------------------------------------------------*/
/*!
 * Clear gpio to 0
 *
 * \param gpio number
 *
 * \return 0 OK, <0 error
 */
static int clear_gpio( int gpio ) 
{
	// release file handler of led
  if (led_fh==-1)
	{	
		return -1;
	}
	
	if (write(led_fh,"0",1)<0)
	{
		return -errno;
	};
	
	return 0;
}

/*--------------------------------------------------------------------*/
/*!
 * Intercept the ctrl-c
 *
 * \param sig signal
 *
 * \return none
 */
static void ctrlc_handler( int sig ) 
{
  quitReq = 1;

}

/*--------------------------------------------------------------------*/
/*! Kbhit helper function
 *
 * \return A value :
 *      - 1 Character pending 
 *      - 0 no character
 *			- -1 error
 */
int kbhit(void)
{
	struct timeval tv;
	fd_set read_fd;  /* Do not wait at all, not even a microsecond */
  
  tv.tv_sec=0;
  tv.tv_usec=0;  /* Must be done first to initialize read_fd */
  FD_ZERO(&read_fd);  /* Makes select() ask if input is ready:   *
                         0 is the file descriptor for stdin      */
  FD_SET(0,&read_fd);  /* The first parameter is the number of the *
                          largest file descriptor to check + 1. */
  if(select(1, &read_fd, NULL, /*No writes*/ NULL, /*No exceptions*/
&tv) == -1)
    return -1; /* An error occured */

  /* read_fd now holds a bit map of files that are   *
     readable. We test the entry for the standard    *
     input (file 0). */
  if(FD_ISSET(0,&read_fd))    /* Character pending on stdin */
    return 1; 
    
    
  /* no characters were pending */
  
  return 0;

} 

/*--------------------------------------------------------------------*/
/*! Set interface attribute for serial port (8 bit)
 * \param fd file descriptor
 *				speed baudrate
 *				parity parity
 * 
 * \return A value :
 *      - 0 no error
 *			- <0 error occured
 *      
 */
int set_interface_attribs (int fd, int speed, int parity)
{
  struct termios tty;
  memset (&tty, 0, sizeof tty);
  if (tcgetattr (fd, &tty) != 0)
  {
    printf("set_interface_attribs: Error using tcgetattr\n");
    return -1;
  }

  cfsetospeed (&tty, speed);
  cfsetispeed (&tty, speed);

  tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;     // 8-bit chars
  // disable IGNBRK for mismatched speed tests; otherwise receive break
  // as \000 chars
  tty.c_iflag &= ~IGNBRK;         // ignore break signal
  tty.c_lflag = 0;                // no signaling chars, no echo,
                                  // no canonical processing
  tty.c_oflag = 0;                // no remapping, no delays
  tty.c_cc[VMIN]  = 0;            // read doesn't block
  tty.c_cc[VTIME] = 5;            // 0.5 seconds read timeout

  tty.c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl

  tty.c_cflag |= (CLOCAL | CREAD);// ignore modem controls,
                                  // enable reading
  tty.c_cflag &= ~(PARENB | PARODD);      // shut off parity
  tty.c_cflag |= parity;
  tty.c_cflag &= ~CSTOPB;
  tty.c_cflag &= ~CRTSCTS;

  if (tcsetattr (fd, TCSANOW, &tty) != 0)
  {
    printf("Error from tcsetattr\n");
    return -2;
  }
  return 0;
}

/*--------------------------------------------------------------------*/
/*! Modify setting
 \param	 name setting name
				value setting value
 \return  -1 no setting available
 					-2 i2c error
					0 no error
 */ 
int set_setting(char *name, int value) {
	int i;
	char buf[MAX_I2C_SIZE];
	
	for (i=0;i<SETTINGS_NUMBER;i++) {
		if (strncmp(settings_name[i], name,strlen(settings_name[i]))==0) {
			settings_value[i]=value;
			settings_used[i]=1;
			
			// if i2c parameter
			if (settings_i2creg[i]>=0) {			
				buf[0]= value & 0xFF;
				for (int j=1;j<settings_i2csize[i];j++)
				{
					buf[j]=(value>>(j*8))& 0xFF;
				}	
				if (i2c_write( boards_i2c_addr[settings_board[i]],settings_i2creg[i],buf,settings_i2csize[i])<0) {
					// i2c error
					return -2;
				} else
				{ // read ok
				}
			} else {
			  // not an i2c setting
				
				// set special board i2c address
				if (i==eLEFT_I2C)
				{
					boards_i2c_addr[0]=settings_value[eLEFT_I2C];
				} else if (i==eRIGHT_I2C)
				{
					boards_i2c_addr[1]=settings_value[eRIGHT_I2C];
				} else if (i==eNECK_I2C)
				{
					boards_i2c_addr[2]=settings_value[eNECK_I2C];
				} 
			}
			return 0;
		}
	}
			
	return -1;		
}

/*--------------------------------------------------------------------*/
/*! Get setting value
 \param	 name setting name
				 value setting value
 \return  -1 no such setting available
					-2 i2c error
					//-3 setting not used
					0 no error
 */ 
int get_setting(char *name, int *value) {
	int i;
	char buf[MAX_I2C_SIZE];
	
	for (i=0;i<SETTINGS_NUMBER;i++) {
		if (strncmp(settings_name[i], name,strlen(settings_name[i]))==0) {
			// setting present
			
			// if i2c parameter
			if (settings_i2creg[i]>=0)
			{
				if (i2c_read( boards_i2c_addr[settings_board[i]],settings_i2creg[i],buf,settings_i2csize[i])<0) {
					// i2c error
					return -2;
				} else
				{ // read ok
					*value=buf[0];
					
					// read other byte(s)
					for (int j=1;j<settings_i2csize[i];j++)
					{
						*value|=buf[j]<<(j*8);
					}
					settings_value[i]=*value;	
				}
			
			} else {
				*value=settings_value[i];
			}
					
			/*if (settings_used[i]) { // in use
				
			} else
			{ // not used
				return -3;
			}*/		
			return 0;
		}
	}
			
	return -1;		
}

/*--------------------------------------------------------------------*/
/*! Modify variable
 \param	 name variable name
				value variable value
 \return  -1 no variable available
					-2 i2c error
					0 no error
 */ 
int set_variable(char *name, int value) {
	int i;
	char buf[MAX_I2C_SIZE];
	
	for (i=0;i<VARIABLES_NUMBER;i++) {
		if (strncmp(variables_name[i], name,strlen(variables_name[i]))==0) {
			variables_value[i]=value;
			
			buf[0]= value & 0xFF;
			for (int j=1;j<variables_i2csize[i];j++)
			{
				buf[j]=(value>>(j*8))& 0xFF;
			}
			
			if (i2c_write( boards_i2c_addr[variables_board[i]],variables_i2creg[i],buf,variables_i2csize[i])<0) {
				// i2c error
				return -2;
			} else
			{ // read ok
			}
			
			return 0;
		}
	}			
	return -1;		
}

/*--------------------------------------------------------------------*/
/*! Get variable value
 \param	 name variable name
				 value variable value
 \return  -1 no such variable available
					-2 i2c error
					0 no error
 */ 
int get_variable(char *name, int *value) {
	int i;
	char buf[MAX_I2C_SIZE];
	
	for (i=0;i<VARIABLES_NUMBER;i++) {
		if (strncmp(variables_name[i], name,strlen(variables_name[i]))==0) {
			// variable present
			if (i2c_read( boards_i2c_addr[variables_board[i]],variables_i2creg[i],buf,variables_i2csize[i])<0) {
				// i2c error
				return -2;
			} else
			{ // read ok
				*value=buf[0];
				for (int j=1;j<variables_i2csize[i];j++)
				{
					*value|=buf[j]<<(j*8);
				}
				variables_value[i]=*value;	
				return 0;
			}
		}
	}		
	return -1;		
}


/*--------------------------------------------------------------------*/
/*! disable
 \param	 name setting name
				 value setting value
 \return  -1 no such setting available
					0 no error
 */ 
int disable_setting(char *name) {
	int i;
	
	for (i=0;i<SETTINGS_NUMBER;i++) {
		if (strncmp(settings_name[i], name,strlen(settings_name[i]))==0) {
			if (settings_used[i]) { // in use
				settings_used[i]=0;
				#ifdef DEBUG
				printf("DEBUG: disabling parameter: %s\n",settings_name[i]);
				#endif	
				return 0;
			}
		}
	}		
	return -1;		
}

/*--------------------------------------------------------------------*/
/*! Read the config file and load settings
 \return  <0 when configuration file could not be read correctly
					0 when configuration file was successfully read.
 */ 
int load_settings()
{
  // set the default values for the settings
  //set_default_settings(settings);

  // read the configuration settings from a file instead 
  FILE* file;
  if ( (file = fopen(SETTINGS_FILENAME, "r")) == NULL) {
    return -1;
	} else
  {
    // read the configuration file line by line
    char buffer[256];
		int err,idata;
    while ( fgets(buffer, 256, file) != NULL )
    {
      int found=0,i,len;
			
			for (i=0;i<SETTINGS_NUMBER;i++) {
				len=strlen(settings_name[i]);
				if (strncmp(settings_name[i], buffer,len)==0) {
					found=1;
					break;
				}
			}
			
			if (!found) {
				fprintf(stderr,"ERROR: Unknown parameter in settings file %s: %s",SETTINGS_FILENAME,buffer);
				return -2;
			} else
			{
				// found
				#ifdef DEBUG
				printf("DEBUG: found parameter: %s\n",settings_name[i]);
				#endif
				
				err=sscanf(buffer+len+1,settings_scantype[i],&settings_value[i]);
				if((err==EOF) || (err!=1))
				{
					fprintf(stderr,"ERROR: Invalid line for parameter %s in settings file %s: %s",settings_name[i],SETTINGS_FILENAME,buffer);
					fclose(file);
					return -3;
				}
				
				settings_used[i]=1;
				
				#ifdef DEBUG
				char _buf[64];
				snprintf(_buf,64,"DEBUG: Value of parameter %s is: %s \n",settings_name[i],settings_printtype[i]);
				printf(_buf,settings_value[i]);
				#endif
			}
    }

    // close the configuration file
    fclose(file);
  }
  
	// ------ set defaults settings
	
	// set i2c addresses settings read on file or use default
	if (settings_used[eLEFT_I2C])
	{
		boards_i2c_addr[0]=settings_value[eLEFT_I2C];
	} else
	{
		// set defaut i2c
		boards_i2c_addr[0]=settings_value[eLEFT_I2C]=DEFAULT_LEFT_MOTOR_I2C_ADDRESS;
	}
	
	if (settings_used[eRIGHT_I2C])
	{
		boards_i2c_addr[1]=settings_value[eRIGHT_I2C];
	} else {
		boards_i2c_addr[1]=settings_value[eRIGHT_I2C]=DEFAULT_RIGHT_MOTOR_I2C_ADDRESS;
	}
	
	if (settings_used[eNECK_I2C])
	{
		boards_i2c_addr[2]=settings_value[eNECK_I2C];
	} else {
		boards_i2c_addr[2]=settings_value[eNECK_I2C]=DEFAULT_NECK_MOTOR_I2C_ADDRESS;
	}
	
	
	if (!settings_used[ePORT]) {
			settings_value[ePORT]=DEFAULT_SERVER_PORT;
	}
	
	if (!settings_used[eLED_GPIO]) {
			settings_value[eLED_GPIO]=DEFAULT_LED_GPIO_NB;
	}
	
  return 0;
}

/*--------------------------------------------------------------------*/
/*! Write to config file only the load or added (used) settings
 \return  <0 when configuration file could not be written successfully
					0 when configuration file was successfully read.
 */ 
int save_settings()
{
  FILE* file;
  if ( (file = fopen(SETTINGS_FILENAME, "w")) == NULL) {
    return -1;
	}	else
  {
    char buffer[256];
		int err,i;
		
		for (i=0;i<SETTINGS_NUMBER;i++) {
			if (settings_used[i]) { // test if setting is used and write it to the file
				snprintf(buffer,256,"%s=%s\n",settings_name[i],settings_printtype[i]);
				if (fprintf(file,buffer,settings_value[i])<0)
				{
					return -2;
				}
			}
		}	
			
    // close the configuration file
    if (fclose(file) != 0) {
			return -3;
		}
  }
  return 0;
}


/*--------------------------------------------------------------------*/
/*! send to i2c all used settings to boards
 \return  <0 error occurred
					0 no error
 */ 
int send_i2c_all_settings()
{
	int i,err=0;
	
	for (i=0;i<SETTINGS_NUMBER;i++) {
		// test if setting is used and is i2c and is a board setting
		if (settings_used[i] && (settings_i2csize[i]>0) && (settings_board[i]>=0)) { 		
			#ifdef DEBUG
			printf("Sending setting %s val=%d to board address=0x%x, register=%x, size=%d\n",settings_name[i],settings_value[i],boards_i2c_addr[settings_board[i]],settings_i2creg[i],settings_i2csize[i]);
			#endif			
			
			char buf[MAX_I2C_SIZE];
	
			
			buf[0]= settings_value[i] & 0xFF;
			for (int j=1;j<settings_i2csize[i];j++)
			{
				buf[j]=(settings_value[i]>>(j*8))& 0xFF;
			}
			
			
			if (i2c_write( boards_i2c_addr[settings_board[i]],settings_i2creg[i],buf,settings_i2csize[i] )<0) {
				fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[i],settings_value[i],boards_i2c_addr[settings_board[i]],settings_i2creg[i],settings_i2csize[i],strerror(errno));
				err+=-1;	
			}	
			else
			{
				#ifdef DEBUG
				printf("  write i2c OK\n");
				#endif	
			}		
		}
	}	
  return err;
}


/*--------------------------------------------------------------------*/
/*! send data from socket
 \return  <0 error occurred
					>= number of data sent
 */ 
int sendSocketData( int sockfd,char *buffer, int len ) {
  int n;

  if ( (n = write( sockfd, buffer, len ) ) < 0 ) {
	#ifdef DEBUG
    perror( const_cast<char *>( "ERROR writing to socket in sendSocketData") );
	#endif
  }
  
  return n;
}

/*--------------------------------------------------------------------*/
/*! get data from socket
 \return  <0 error occurred
					>= number of data received
 */ 
int getSocketData( int sockfd,char *buffer,int len ) {
  int n;

  if ( (n = read(sockfd,buffer,len) ) < 0 ){
	
		// disconnected or other error
		//printf("DEBUG: ERROR reading from socket in getSocketData at line %d: %s\n", __LINE__, strerror(errno) );
	
  }	
  else
	buffer[n] = '\0';
  return n;
}


/*--------------------------------------------------------------------*/
/*! set robot motors mode
	\param left left motor mode
				 right right motor mode
	\return  0 no error occured
					-1 left i2c error occured
					-2 right i2c error occured
					-3 left and right motor i2c error
 */ 
int set_drive_motors_mode(int left, int right) {
	int err=0;
	char buf[MAX_I2C_SIZE];
	
	// left
	buf[0]= left & 0xFF;
	for (int j=1;j<variables_i2csize[eLEFT_CONTROL];j++)
	{
		buf[j]=(left>>(j*8))& 0xFF;
	}
	if (i2c_write( boards_i2c_addr[eLEFT_BOARD],variables_i2creg[eLEFT_CONTROL],buf,variables_i2csize[eLEFT_CONTROL] )<0) {	
		err=-1;
	}	

	// right
	buf[0]= right & 0xFF;
	for (int j=1;j<variables_i2csize[eRIGHT_CONTROL];j++)
	{
		buf[j]=(right>>(j*8))& 0xFF;
	}
	if (i2c_write( boards_i2c_addr[eRIGHT_BOARD],variables_i2creg[eRIGHT_CONTROL],buf,variables_i2csize[eRIGHT_CONTROL] )<0) {
		err+=-2;
	}	
	return err;
}


/*--------------------------------------------------------------------*/
/*! send robot speed
 \return  0 no error occured
					-1 left i2c error occured
					-2 right i2c error occured
					-3 left and right motor i2c error	
 */ 
int set_drive_speed(int left, int right) {
	int err=0;
	char buf[MAX_I2C_SIZE];
	
	// left
	buf[0]= left & 0xFF;
	for (int j=1;j<variables_i2csize[eLEFT_SPEED];j++)
	{
		buf[j]=(left>>(j*8))& 0xFF;
	}
	if (i2c_write( boards_i2c_addr[eLEFT_BOARD],variables_i2creg[eLEFT_SPEED],buf,variables_i2csize[eLEFT_SPEED] )<0) {	
		err=-1;
	}	

	// right
	buf[0]= right & 0xFF;
	for (int j=1;j<variables_i2csize[eRIGHT_SPEED];j++)
	{
		buf[j]=(right>>(j*8))& 0xFF;
	}
	if (i2c_write( boards_i2c_addr[eRIGHT_BOARD],variables_i2creg[eRIGHT_SPEED],buf,variables_i2csize[eRIGHT_SPEED] )<0) {
		err+=-2;
	}	
	return err;
}

/*--------------------------------------------------------------------*/
/*! check if robot motor left and right have reached its position
 \return  0 none of left or right has reach position
					1 motor left only has reached position
					2 motor right only has reached position
					3 both have reached position					
					-1 left i2c error occured
					-2 right i2c error occured

 */ 
int check_position_reached() {
 char buff[1];
 int ret=0;

	if (i2c_read( boards_i2c_addr[eLEFT_BOARD],variables_i2creg[eLEFT_ON_TRGT],buff,1)<0) {
			// i2c error
			return -1;
	}

	ret=buff[0];
	
	if (i2c_read( boards_i2c_addr[eRIGHT_BOARD],variables_i2creg[eRIGHT_ON_TRGT],buff,1)<0) {
			// i2c error
			return -2;
	}
	
	ret+=2*buff[0];
	
	return ret;
}			

/*--------------------------------------------------------------------*/
/*! send robot position
 \return  0 no error occured
					-1 left i2c error occured
					-2 right i2c error occured
					-3 left and right motor i2c error	
 */ 
int set_drive_position(int left, int right) {
	int err=0;
	char buf[MAX_I2C_SIZE];
	
	// left
	buf[0]= left & 0xFF;
	for (int j=1;j<variables_i2csize[eLEFT_POS];j++)
	{
		buf[j]=(left>>(j*8))& 0xFF;
	}
	if (i2c_write( boards_i2c_addr[eLEFT_BOARD],variables_i2creg[eLEFT_POS],buf,variables_i2csize[eLEFT_POS] )<0) {	
		err=-1;
	}	

	
	// right
	buf[0]= right & 0xFF;
	for (int j=1;j<variables_i2csize[eRIGHT_POS];j++)
	{
		buf[j]=(right>>(j*8))& 0xFF;
	}
	if (i2c_write( boards_i2c_addr[eRIGHT_BOARD],variables_i2creg[eRIGHT_POS],buf,variables_i2csize[eRIGHT_POS] )<0) {
		err+=-2;
	}	
	return err;
}


/*--------------------------------------------------------------------*/
/*! get robot position
 \return  0 no error occured
					-1 left i2c error occured
					-2 right i2c error occured
					-3 left and right motor i2c error	
 */ 
int get_drive_position(int *left, int *right) {
	int err=0;
	char buf[MAX_I2C_SIZE];
	
	// left

	if (i2c_read( boards_i2c_addr[eLEFT_BOARD],variables_i2creg[eLEFT_ACT_POS],buf,variables_i2csize[eLEFT_ACT_POS] )<0) {	
		err=-1;
	}	

	*left=buf[0];					
	// read other byte(s)
	for (int j=1;j<variables_i2csize[eLEFT_ACT_POS];j++)
	{
		*left|=buf[j]<<(j*8);
	}


	// right

	if (i2c_read( boards_i2c_addr[eRIGHT_BOARD],variables_i2creg[eRIGHT_ACT_POS],buf,variables_i2csize[eRIGHT_ACT_POS] )<0) {
		err+=-2;
	}	
	
	*right=buf[0];					
	// read other byte(s)
	for (int j=1;j<variables_i2csize[eRIGHT_ACT_POS];j++)
	{
		*right|=buf[j]<<(j*8);
	}
	
	return err;
}

/*--------------------------------------------------------------------*/
/*! get robot speed
 \return  0 no error occured
					-1 left i2c error occured
					-2 right i2c error occured
					-3 left and right motor i2c error	
 */ 
int get_drive_speed(int *left, int *right) {
	int err=0;
  short Speed_temp; 
	char buf[MAX_I2C_SIZE];
	
	// left

	if (i2c_read( boards_i2c_addr[eLEFT_BOARD],variables_i2creg[eLEFT_ACT_SPEED],buf,variables_i2csize[eLEFT_ACT_SPEED] )<0) {	
		err=-1;
	}	

	//*left=buf[0];
  Speed_temp = 	buf[0];				
	// read other byte(s)
	for (int j=1;j<variables_i2csize[eLEFT_ACT_SPEED];j++)
	{
		//*left|=buf[j]<<(j*8);
    Speed_temp|=buf[j]<<(j*8);
	}
  *left = Speed_temp;

	// right

	if (i2c_read( boards_i2c_addr[eRIGHT_BOARD],variables_i2creg[eRIGHT_ACT_SPEED],buf,variables_i2csize[eRIGHT_ACT_SPEED] )<0) {
		err+=-2;
	}	
	
	//*right=buf[0];
  Speed_temp = buf[0];					
	// read other byte(s)
	for (int j=1;j<variables_i2csize[eRIGHT_ACT_SPEED];j++)
	{
		//*right|=buf[j]<<(j*8);
    Speed_temp|=buf[j]<<(j*8);
	}
  *right = Speed_temp;
	
	return err;
}

/*--------------------------------------------------------------------*/
/*! send robot speed
 \return  0 no error occured
					-1 left i2c error occured
					-2 right i2c error occured
					-3 left and right motor i2c error	
 */
int stop_drive_motors() {
    set_drive_motors_mode(eCTRL_SPEED_ACC,eCTRL_SPEED_ACC);
    set_drive_speed(0,0);
    usleep(500000);
    return set_drive_motors_mode(eCTRL_IDLE,eCTRL_IDLE);
}


int stop_drive_motors_old() {
    return set_drive_speed(0,0);
}

/*--------------------------------------------------------------------*/
/*! set neck motor mode
	\param 
	\return  0 no error occured
					-1 neck i2c error occured

 */ 
int set_neck_motor_mode(int neck) {
	int err=0;
	char buf[MAX_I2C_SIZE];
	

	buf[0]= neck & 0xFF;
	for (int j=1;j<variables_i2csize[eNECK_CONTROL];j++)
	{
		buf[j]=(neck>>(j*8))& 0xFF;
	}
	if (i2c_write( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_CONTROL],buf,variables_i2csize[eNECK_CONTROL] )<0) {	
		err=-1;
	}	

	return err;
}


/*--------------------------------------------------------------------*/
/*! set pwm to neck motor
	\param neck motor pwm (-400 (-100%) to 400 (100%) )
	\return  0 no error occured
					-1 i2c error occured

 */ 
int set_neck_motor_pwm(int pwm) {
	int err=0;
	char buf[MAX_I2C_SIZE];
	
	// right
	buf[0]= pwm & 0xFF;
	for (int j=1;j<variables_i2csize[eNECK_PWM];j++)
	{
		buf[j]=(pwm>>(j*8))& 0xFF;
	}
	
	if (i2c_write( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_PWM],buf,variables_i2csize[eNECK_PWM] )<0) {
		return -1;
	}	
	
	return 0;
}

/*--------------------------------------------------------------------*/
/*! stop neck motor
	\return  0 no error occured
					-1 i2c error occured
 */ 
int stop_neck_motor() {
	return set_neck_motor_pwm(0);
}


/*--------------------------------------------------------------------*/
/*! rotate the neck to origin position
	\return  0 no error occurred			
					< 0 error

 */ 
int neck_origin() {
	int sw1=0,sw2=0;
  int Timer = 0;
	char buf[MAX_I2C_SIZE];
	
		// test if neck nominal value is initialised
	if (settings_value[eNECK_NOM_PWM]==0)
	{
		#ifdef DEBUG
		printf("DEBUG:  neck_origin nominal pwm not set for neck!\n");	
		#endif
		return -1;
	}
	
	neck_current_angle=neck_current_time*NECK_SW1_SW2_RANGE_ANGLE/neck_sw1_sw2_range_time;
	
	if (neck_current_angle<0) {
		// move right
		
		// going right
		set_neck_motor_pwm(settings_value[eNECK_NOM_PWM]);
		
		sw1=1; 
    Timer = 0;
		while ((sw1==1) && (Timer < NECK_SAFE_TIMER))
		{
      Timer++;
			usleep(1000);
			// check right switch
			if (i2c_read( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_SW1],buf,variables_i2csize[eNECK_SW1])<0) {
			// i2c error
			return -3;
			} else { // read ok
				sw1=buf[0];
			}
		}
    if(sw1 == 1)                                  // No switch detected
    {
      stop_neck_motor();
      return -5;
    
    }
		
	
	} else if (neck_current_angle>0) {
		// move left

		// going left
		set_neck_motor_pwm(-settings_value[eNECK_NOM_PWM]);

		sw1=1; 
    Timer = 0;
		while ((sw1==1) && (Timer < NECK_SAFE_TIMER))
		{
      Timer++;
			usleep(1000);
			// check right switch
			if (i2c_read( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_SW1],buf,variables_i2csize[eNECK_SW1])<0) {
			// i2c error
			return -4;
			} else { // read ok
				sw1=buf[0];
			}
		}
    if(sw1 == 1)                                  // No switch detected
    {
      stop_neck_motor();
      return -5;
    
    }    
	}
	
	
	stop_neck_motor();
	
	neck_current_angle=0;
	neck_current_time=0;
	
	usleep(100000);
	
	return 0;
}

/*--------------------------------------------------------------------*/
/*! rotate the neck to low position
	\return  0 no error occurred			
					< 0 error

 */ 
int neck_low() {
	int sw1=0,sw2=0;
  int Timer = 0;
	char buf[MAX_I2C_SIZE];
	
		// test if neck nominal value is initialised
	if (settings_value[eNECK_NOM_PWM]==0)
	{
		#ifdef DEBUG
		printf("DEBUG:  neck_low nominal pwm not set for neck!\n");	
		#endif
		return -1;
	}

	// directly on switch?
	sw2=1;
	if (i2c_read( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_SW2],buf,variables_i2csize[eNECK_SW2])<0) {
	// i2c error
	return -3;
	}	
  else { // read ok
		sw2=buf[0];
	}
  
  if (sw2==1) {// not on switch
  
	neck_current_angle=neck_current_time*NECK_SW1_SW2_RANGE_ANGLE/neck_sw1_sw2_range_time;
	

		// move right
		
		// going right
		set_neck_motor_pwm(settings_value[eNECK_NOM_PWM]);
		
		sw2=1; 
    Timer = 0;
		while ((sw2==1) && (Timer < NECK_SAFE_TIMER))
		{
      Timer++;
			usleep(1000);
			// check right switch
			if (i2c_read( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_SW2],buf,variables_i2csize[eNECK_SW2])<0) {
			// i2c error
			return -3;
			} else { // read ok
				sw2=buf[0];
			}
		}
    if(sw2 == 1)                                  // No switch detected
    {
      stop_neck_motor();
      return -5;
    
    }    
		
	
  }
	
	
	stop_neck_motor();
	
	neck_current_angle=18;
	neck_current_time=neck_sw1_sw2_range_time;
	
	usleep(100000);
	
	return 0;
}

/*--------------------------------------------------------------------*/
/*! rotate the neck
	\param angle angle in degree (>0 is right,0 is at sw1, <0 is left)
	\return  0 no error occurred					
					< 0 error

 */ 
int rotate_neck(int angle) {
	int sw1=0,sw2=0;
	char buf[MAX_I2C_SIZE];
	struct timeval startt, endt;
	int secs_used,micros_used=0,micros_needed;
	
	// test if neck nominal value is initialised
	if (settings_value[eNECK_NOM_PWM]==0)
	{
		#ifdef DEBUG
		printf("DEBUG:  neck_rotate nominal pwm not set for neck!\n");	
		#endif
		return -1;
	}
	
	neck_current_angle=neck_current_time*NECK_SW1_SW2_RANGE_ANGLE/neck_sw1_sw2_range_time;
	
	if (angle>neck_current_angle) {
		// move right
		
		
		// compute needed time to reach angle
		micros_needed=((3*angle*neck_sw1_sw2_range_time/NECK_SW1_SW2_RANGE_ANGLE) / 2)-neck_current_time;
		
		// going right
		set_neck_motor_pwm(settings_value[eNECK_NOM_PWM]);
		
		gettimeofday(&startt, NULL);
		sw2=1; 
		while ((sw2==1) && (micros_used<micros_needed))
		{
			usleep(10000);
			// check right switch
			if (i2c_read( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_SW2],buf,variables_i2csize[eNECK_SW2])<0) {
			// i2c error
			return -3;
			} else { // read ok
				sw2=buf[0];
			}
			gettimeofday(&endt, NULL);
			secs_used=(endt.tv_sec - startt.tv_sec); //avoid overflow by subtracting first
			micros_used= ((secs_used*1000000) + endt.tv_usec) - (startt.tv_usec);
			
			
		}
		neck_current_time+=micros_used;
	
	} else if (angle<neck_current_angle) {
		// move left
		// compute needed time to achieve angle
		micros_needed=neck_current_time-(angle*neck_sw1_sw2_range_time/NECK_SW1_SW2_RANGE_ANGLE);

		// going left
		set_neck_motor_pwm(-settings_value[eNECK_NOM_PWM]);

		gettimeofday(&startt, NULL);

		while (((neck_current_time-micros_used)>-neck_sw1_sw2_range_time) && (micros_used<micros_needed)) // limit reach or angle reached
		{
			usleep(10000);

			gettimeofday(&endt, NULL);
			secs_used=(endt.tv_sec - startt.tv_sec); //avoid overflow by subtracting first
			micros_used= ((secs_used*1000000) + endt.tv_usec) - (startt.tv_usec);
			
			
		}

		neck_current_time-=micros_used;
	}
	
	
	stop_neck_motor();
	
	neck_current_angle=neck_current_time*NECK_SW1_SW2_RANGE_ANGLE/neck_sw1_sw2_range_time;
	
	usleep(100000);
	
	return 0;
}

/*--------------------------------------------------------------------*/
/*! initialise neck motor, put it to center position, and compute time between sw1 (at center) and sw2 (at the right)
	\param 
	\return  0 no error occurred
					
					< 0 error

 */ 
 
int init_neck() {
	int err=0,out=0,sw1=0,sw2=0;
  int Timer = 0;
	char buf[MAX_I2C_SIZE];
	struct timeval startt, endt;
	int secs_used,micros_used;
	
	
	// test if neck nominal value is initialised
	if (settings_value[eNECK_NOM_PWM]==0)
	{
		#ifdef DEBUG
		printf("DEBUG: init_neck nominal pwm not set for neck!\n");	
		#endif
		return -1;
	}
	
	

	// finding switch 2
	
	// directly on switch?
	sw2=1;
	if (i2c_read( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_SW2],buf,variables_i2csize[eNECK_SW2])<0) {
	// i2c error
	return -3;
	} else { // read ok
		sw2=buf[0];
	}
	
	if (sw2==1) {// not on switch
	
		// going right
		buf[0]= settings_value[eNECK_NOM_PWM];
		for (int j=1;j<variables_i2csize[eNECK_PWM];j++)
		{
			buf[j]=(settings_value[eNECK_NOM_PWM]>>(j*8))& 0xFF;
		}
		if (i2c_write( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_PWM],buf,variables_i2csize[eNECK_PWM] )<0) {	
			return -5;
		}	

		
		sw2=1; 
    Timer = 0;
		while ((sw2==1) && (Timer < NECK_SAFE_TIMER))
		{
      Timer++;
			usleep(1000);
			if (i2c_read( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_SW2],buf,variables_i2csize[eNECK_SW2])<0) {
			// i2c error
			return -3;
			} else { // read ok
				sw2=buf[0];
			}
		}
    if(sw2 == 1)                                  // No switch detected
    {
      stop_neck_motor();
      return -5;
    
    }      
		
		// stop neck
		buf[0]= 0;
		buf[1]= 0;
		if (i2c_write( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_PWM],buf,variables_i2csize[eNECK_PWM] )<0) {	
			return -4;
		}	
		
		usleep(500000);
	
	}
	
	// going left
	buf[0]= -settings_value[eNECK_NOM_PWM];
	for (int j=1;j<variables_i2csize[eNECK_PWM];j++)
	{
		buf[j]=(-settings_value[eNECK_NOM_PWM]>>(j*8))& 0xFF;
	}
	if (i2c_write( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_PWM],buf,variables_i2csize[eNECK_PWM] )<0) {	
		return -5;
	}	
	gettimeofday(&startt, NULL);

	// finding center switch 1
	sw1=1;
	
	Timer = 0;
	while ((sw1==1) && (Timer < NECK_SAFE_TIMER))
	{
    Timer++;
		usleep(1000);
		if (i2c_read( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_SW1],buf,variables_i2csize[eNECK_SW1])<0) {
		// i2c error
		return -6;
		} else { // read ok
			sw1=buf[0];
		}	
	}
  if(sw1 == 1)                                  // No switch detected
  {
    stop_neck_motor();
    return -5;
  }    
	gettimeofday(&endt, NULL);
	
	// stop neck
	buf[0]= 0;
	buf[1]= 0;
	if (i2c_write( boards_i2c_addr[eNECK_BOARD],variables_i2creg[eNECK_PWM],buf,variables_i2csize[eNECK_PWM] )<0) {	
		return -7;
	}	
	
	secs_used=(endt.tv_sec - startt.tv_sec); //avoid overflow by subtracting first
  neck_sw1_sw2_range_time=micros_used= ((secs_used*1000000) + endt.tv_usec) - (startt.tv_usec); // save to global variable
	
	#ifdef DEBUG
	printf("DEBUG: sw1 - sw2 time range: %ld [us]\n",neck_sw1_sw2_range_time);
	#endif
	
	neck_current_angle=0;
	neck_current_time=0;
	
	return 0;
}




/*--------------------------------------------------------------------*/
/*! compute Pelco D checksum
	\param rsbuff Pelco D array
	\return < 0 error
					>=0 checksum
 */ 
int pelcod_checksum(char *rsbuff)
{
	int ret=0,i;
	if (rsbuff == NULL)
		return -1;
	
	for (i=1;i<RS485_PELCOD_CMD_SIZE-1;i++)
	{
		ret+=rsbuff[i];
	}
	
	ret%=256; 
	
	return ret;
}

/*--------------------------------------------------------------------*/
/*! stop pan-tilt
 \return  -1 rs485 port not correctly open
					-2 write error to rs485 port
					>=0 OK
 */ 
int stop_pan_tilt() {
	char rsbuff[RS485_PELCOD_CMD_SIZE];
	
		if (rs485_fd == -1)
		return -1;
		
		// stop pan and tilt
		// Pelco D
		rsbuff[0]=0xff; // synchronization
		rsbuff[1]=PAN_TILT_PELCOD_ADDRESS;  // device address
		rsbuff[2]=0; // Command 1
		rsbuff[3]=PAN_TILT_PELCOD_COMMAND_2_PAN_LEFT | PAN_TILT_PELCOD_COMMAND_2_TILT_UP; // Command 2
		rsbuff[4]=0; // Data 1
		rsbuff[5]=0; // Data 2
		rsbuff[6]=pelcod_checksum(rsbuff); // Checksum
		if (write(rs485_fd,rsbuff,RS485_PELCOD_CMD_SIZE) == -1)
		{
			return -2;
		}
		
	return 0;	
}

/*****************************************************************************/
/*! difference between two angles in degree, modulo 180
 * \param a first angle
 * \param b second angle 
 *
 * \return result 
*/
double diff_angles(double a, double b) {
	double ret;
	
	ret = a-b;
	
	if (ret>180)
		ret-=360;
	else
		if (ret<-180)
			ret+=360;
			
	return ret;

}

/*****************************************************************************/
/*! sum between two angles in degree, modulo 180
 * \param a first angle
 * \param b second angle 
 *
 * \return result 
*/
double sum_angles(double a, double b) {
	double ret;
	
	ret = a+b;
	
	if (ret>180)
		ret-=360;
	else
		if (ret<-180)
			ret+=360;		
	return ret;

}


/*****************************************************************************/
/*!
 * make one increment of moving robot to x,y,angle; must be called periodically
 * very basic algorithm: rotate to be in direction to the goal xy, move straight to goal position and rotate to goal angle
 *
 * \param curr_x current x position [mm]
 * \param curr_y current a position [mm]
 * \param curr_a current angle position [degree]
 * \param goal_x goal x position [mm]
 * \param goal_y goal a position [mm]
 * \param goal_a goal angle position [degree]
 * \param dist2goal return computed distance to goal	
 * \param angle2goal return computed angle to goal (or to direction to goal when moving)	 
 * \return 	0 : reached destination
 *					1 : first rotation
 *					2 : translation
 *					3 : final rotation
 *          <0 error occured
 */

// goto xya states 
enum enum_goto_states{eGOTO_START=0,eGOTO_START_ANGLE,eGOTO_SEARCH_START_ANGLE,eGOTO_START_POSITION,eGOTO_SEARCH_POSITION,eGOTO_END_ANGLE,eGOTO_SEARCH_END_ANGLE,eGOTO_END};
const char *goto_states_names[]={"goto starting","goto start angle","goto searching start angle","goto position angle","goto searching position","goto end angle","goto searching end angle","goto end"};
int goto_state;
 
int goto_xya(double curr_x,double curr_y, double curr_a, double goal_x,double goal_y,double goal_a, double *dist2goal, double *angle2goal) {
	double dx,dy,da,dist; 
	int ret;
	
	int left,right,targetl,targetr;
	
  switch(goto_state) {
		eGOTO_START:
		
			goto_state=eGOTO_START_ANGLE;

			dist=sqrt((curr_y-goal_y)*(curr_y-goal_y)+(curr_x-goal_x)*(curr_x-goal_x));
			*dist2goal=dist;
			
			da = diff_angles(goal_a,curr_a);
			*angle2goal=da;
			
			break;
			
		eGOTO_START_ANGLE:
			// compute start angle
			if ((curr_x-goal_x) == 0)
			{
				// parallel to y axis
				if (curr_y>goal_y)
					da = 180;
				else
					da = 0;
			}
			else
			if ((curr_y-goal_y) == 0)
			{
				// parallel to x axis
				if (curr_x>goal_x)
					da = 90;
				else
					da = -90;
			}
			{
				// compute angle
				da=atan((goal_y-curr_y)/(goal_x-curr_x))*180.0/M_PI;
				
				// adapt it to origin
				if (curr_x>goal_x)
				{
					da= sum_angles(90,da);
				}
				else
				{
					da= sum_angles(270,da);
				}
				
			}
			// difference between goal angle and direction to goal
			da = diff_angles(da,curr_a);
			*angle2goal=da;
		
	
			get_drive_position(&left,&right);
			// rotate

			targetl=left-settings_value[eLEFT_PULSES_DEG]*da;
			targetr=right+settings_value[eLEFT_PULSES_DEG]*da;
				
			
			set_drive_position(targetl,targetr);
			set_drive_motors_mode(eCTRL_POSITION,eCTRL_POSITION);
			
			ret=1;

			
			goto_state=eGOTO_SEARCH_START_ANGLE;
			
			
			
			break;
			
		eGOTO_SEARCH_START_ANGLE:
			// if at angle (encoder position)
			if (check_position_reached()==0) {
				goto_state=eGOTO_START_POSITION;
				curr_a=sum_angles(curr_a,*angle2goal); // set current angle
			}
			break;
			
		eGOTO_START_POSITION:
			
			
			dist=sqrt((curr_y-goal_y)*(curr_y-goal_y)+(curr_x-goal_x)*(curr_x-goal_x));
			
			get_drive_position(&left,&right);
				
			targetl=left+settings_value[eLEFT_PULSES_DEG]*dist;
			targetr=right+settings_value[eLEFT_PULSES_DEG]*dist;
				
			
			set_drive_position(targetl,targetr);
			set_drive_motors_mode(eCTRL_POSITION,eCTRL_POSITION);
			
			goto_state=eGOTO_SEARCH_POSITION;
			break;
			
		eGOTO_SEARCH_POSITION:
		
			// if at position (encoder position)
			if (check_position_reached()==0) {
					goto_state=eGOTO_END_ANGLE;
					curr_y=goal_y;
					curr_x=goal_x;
			}
		
			break;
			
		eGOTO_END_ANGLE:
			// check if at goal angle
		
			da=diff_angles(goal_a,curr_a);
			*angle2goal=da;
		
			get_drive_position(&left,&right);
			// rotate

			targetl=left-settings_value[eLEFT_PULSES_DEG]*da;
			targetr=right+settings_value[eLEFT_PULSES_DEG]*da;
				
			
			set_drive_position(targetl,targetr);
			set_drive_motors_mode(eCTRL_POSITION,eCTRL_POSITION);
			
			ret=3;
			break;
			
		eGOTO_SEARCH_END_ANGLE:
			// if at angle (encoder position)
			if (check_position_reached()==0) {
					goto_state=eGOTO_END;
					
					curr_a=goal_a;
			}
			break;
		
		eGOTO_END:
		
		
			ret=0;
			break;
		
		default: 
			return -10;
	}

	return ret;
 }
 

 
 


/*--------------------------------------------------------------------*/
/*! proceed data received from client
 \return  < 0 error
					0 no error
 */ 
int proceed_net_data(int sockfd)
{ 
	int idata,n,err,errs,errv;
	char cdata,sdata[SOCKET_MAX_SIZE+1],buffer[SOCKET_MAX_SIZE+1];
	char recvbuff[SOCKET_MAX_SIZE+1];
	char senbuff[SOCKET_MAX_SIZE+1];
	char rsbuff[RS485_PELCOD_CMD_SIZE];
	int left,right;
	
	
	//---- wait and read data from client ---
	if ((n=getSocketData(sockfd,recvbuff,SOCKET_MAX_SIZE ))== -1)
	{
		if (errno==EWOULDBLOCK) {
			// non blocking and no data => return
			return 1;
		}
		
		// error reading 
		perror( const_cast<char *>("ERROR receive") );
		return -1;
		
	} else if (n==0)
	{	// not data => disconnected ?!
	  perror( const_cast<char *>("ERROR receive: disconnected") );
		return -2;
	}
	
	
	#ifdef DEBUG
	printf("\nDEBUG: %s received:\"%s\"\n",__FUNCTION__,recvbuff);	         
	#endif
	
	switch (recvbuff[0]) {
		case 'f': // move robot forward
			#ifdef DEBUG
			printf("DEBUG: Move robot forward!\n");
			#endif
			
			if (mode_gotoxya!=0) {
				sprintf(senbuff,"f NG: in mode goto xya");
			} else {
				err=set_drive_speed(-settings_value[eLEFT_NOM_SPEED],settings_value[eRIGHT_NOM_SPEED]);
				
				if (err==-1) {
					fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eLEFT_NOM_SPEED],settings_value[eLEFT_NOM_SPEED],boards_i2c_addr[eLEFT_BOARD],settings_i2creg[eLEFT_SPEED],settings_i2csize[eLEFT_NOM_SPEED],strerror(errno));
					sprintf(senbuff,"f NG i2c left error");
				}	
				else if (err==-2) {
					// right
					
						fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eRIGHT_NOM_SPEED],settings_value[eRIGHT_NOM_SPEED],boards_i2c_addr[eRIGHT_BOARD],settings_i2creg[eRIGHT_NOM_SPEED],settings_i2csize[eRIGHT_NOM_SPEED],strerror(errno));
						sprintf(senbuff,"f NG i2c right error");
				} else if (err==-3) {
					// left and right
						fprintf(stderr,"ERROR: i2c_write while sending setting to both boards: %s\n",strerror(errno));
						sprintf(senbuff,"f NG i2c left & right error");
				}	else {
					sprintf(senbuff,"f OK");
				}	
			}	
			
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending f") );
			}
			break;
				
		case 'b': // move robot backward
			#ifdef DEBUG
			printf("DEBUG: Move robot backward!\n");
			#endif
			
			if (mode_gotoxya!=0) {
				sprintf(senbuff,"b NG: in mode goto xya");
			} else {
				err=set_drive_speed(settings_value[eLEFT_NOM_SPEED],-settings_value[eRIGHT_NOM_SPEED]);
				
				if (err==-1) {
					fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eLEFT_NOM_SPEED],settings_value[eLEFT_NOM_SPEED],boards_i2c_addr[eLEFT_BOARD],settings_i2creg[eLEFT_SPEED],settings_i2csize[eLEFT_NOM_SPEED],strerror(errno));
					sprintf(senbuff,"b NG i2c left error");
				}	
				else if (err==-2) {
					// right
					
						fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eRIGHT_NOM_SPEED],settings_value[eRIGHT_NOM_SPEED],boards_i2c_addr[eRIGHT_BOARD],settings_i2creg[eRIGHT_NOM_SPEED],settings_i2csize[eRIGHT_NOM_SPEED],strerror(errno));
						sprintf(senbuff,"b NG i2c right error");
				} else if (err==-3) {
					// left and right
						fprintf(stderr,"ERROR: i2c_write while sending setting to both boards: %s\n",strerror(errno));
						sprintf(senbuff,"b NG i2c left & right error");
				}	else {
					sprintf(senbuff,"b OK");
				}	
			}
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending b") );
			}
			break;
		
		case 'i': // init neck
			// shut down
			
			#ifdef DEBUG
			printf("DEBUG: Initialising neck\n");
			#endif
			
			if (init_neck()!=0) {
				sprintf(senbuff,"i NG");
			} else {
				sprintf(senbuff,"i OK");
			}			
			
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending init neck") );
			}
				

			break;
		
		case 'e': // read encoders
		
			if (auto_p) {
				sprintf(senbuff,"e auto end                   ");
			}
			else {
				sprintf(senbuff,"e auto start                 ");
			}
			
			/*if (get_drive_position(&left,&right)!=0) {
				sprintf(senbuff,"e NG");
			} else {
				sprintf(senbuff,"e L:%10d  R:%10d",left,right);
			}*/
		
		
		
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending f") );
			}
			
			auto_p=!auto_p;
			
		break;
		
		case 'v': // read speed
		
			if (auto_p) {
				sprintf(senbuff,"v auto end                   ");
			}
			else {
				sprintf(senbuff,"v auto start                 ");
			}
		
			/*if (get_drive_speed(&left,&right)!=0) {
				sprintf(senbuff,"v NG");
			} else {
				sprintf(senbuff,"v L:%10d  R:%10d",left,right);
			}*/
		
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending v") );
			}
			
			auto_s=!auto_s;
		break;
		
		case 'l': // move robot left
			#ifdef DEBUG
			printf("DEBUG: Move robot left!\n");
			#endif
			
			if (mode_gotoxya!=0) {
				sprintf(senbuff,"l NG: in mode goto xya");
			} else {
			
				//err=set_drive_speed(settings_value[eLEFT_NOM_SPEED],settings_value[eRIGHT_NOM_SPEED]);
        err=set_drive_speed(eROT_SPEED,eROT_SPEED);
				
				if (err==-1) {
					fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eLEFT_NOM_SPEED],settings_value[eLEFT_NOM_SPEED],boards_i2c_addr[eLEFT_BOARD],settings_i2creg[eLEFT_SPEED],settings_i2csize[eLEFT_NOM_SPEED],strerror(errno));
					sprintf(senbuff,"l NG i2c left error");
				}	
				else if (err==-2) {
					// right
					
						fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eRIGHT_NOM_SPEED],settings_value[eRIGHT_NOM_SPEED],boards_i2c_addr[eRIGHT_BOARD],settings_i2creg[eRIGHT_NOM_SPEED],settings_i2csize[eRIGHT_NOM_SPEED],strerror(errno));
						sprintf(senbuff,"l NG i2c right error");
				} else if (err==-3) {
					// left and right
						fprintf(stderr,"ERROR: i2c_write while sending setting to both boards: %s\n",strerror(errno));
						sprintf(senbuff,"l NG i2c left & right error");
				}	else {
					sprintf(senbuff,"l OK");
				}	
			}
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending l") );
			}
			break;
				
		case 'r': // move robot right
			#ifdef DEBUG
			printf("DEBUG: Move robot right!\n");
			#endif
			
			if (mode_gotoxya!=0) {
				sprintf(senbuff,"r NG: in mode goto xya");
			} else {
				//err=set_drive_speed(-settings_value[eLEFT_NOM_SPEED],-settings_value[eRIGHT_NOM_SPEED]);
        err=set_drive_speed(-eROT_SPEED,-eROT_SPEED);
				
			if (err==-1) {
					fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eLEFT_NOM_SPEED],settings_value[eLEFT_NOM_SPEED],boards_i2c_addr[eLEFT_BOARD],settings_i2creg[eLEFT_SPEED],settings_i2csize[eLEFT_NOM_SPEED],strerror(errno));
					sprintf(senbuff,"r NG i2c left error");
				}	
				else if (err==-2) {
					// right
					
						fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eRIGHT_NOM_SPEED],settings_value[eRIGHT_NOM_SPEED],boards_i2c_addr[eRIGHT_BOARD],settings_i2creg[eRIGHT_NOM_SPEED],settings_i2csize[eRIGHT_NOM_SPEED],strerror(errno));
						sprintf(senbuff,"r NG i2c right error");
				} else if (err==-3) {
					// left and right
						fprintf(stderr,"ERROR: i2c_write while sending setting to both boards: %s\n",strerror(errno));
						sprintf(senbuff,"r NG i2c left & right error");
				}	else {
					sprintf(senbuff,"r OK");
				}	
			
			} 
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending r") );
			}
			break;
			
		case 'u': // move neck left
			#ifdef DEBUG
			printf("DEBUG: Move neck up!\n");
			#endif
			//err=set_neck_motor_pwm(-settings_value[eNECK_NOM_PWM]);
      if (rotate_neck(-settings_value[eNECK_NOM_ANGLE])!=0) {
				sprintf(senbuff,"u NG");
			} else
			{
				sprintf(senbuff,"u OK");
			}      
/*			
			if (err==-1) {
				fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eNECK_NOM_PWM],-settings_value[eNECK_NOM_PWM],boards_i2c_addr[eNECK_BOARD],settings_i2creg[eNECK_NOM_PWM],settings_i2csize[eNECK_NOM_PWM],strerror(errno));
				sprintf(senbuff,"u NG i2c neck error");
			}	else
			{
				sprintf(senbuff,"u OK");
			}*/
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending neck up") );
			}
			break;
				
		case 'd': // move neck right
			#ifdef DEBUG
			printf("DEBUG: Move neck down!\n");
			#endif
			//err=set_neck_motor_pwm(settings_value[eNECK_NOM_PWM]);
      if (rotate_neck(settings_value[eNECK_NOM_ANGLE])!=0) {
				sprintf(senbuff,"d NG");
			} else
			{
				sprintf(senbuff,"d OK");
			}
			/*
			if (err==-1) {
				fprintf(stderr,"ERROR: i2c_write while sending setting %s val=%d to board address=0x%x, register=%x, size=%d: %s\n",settings_name[eNECK_NOM_PWM],settings_value[eNECK_NOM_PWM],boards_i2c_addr[eNECK_BOARD],settings_i2creg[eNECK_NOM_PWM],settings_i2csize[eNECK_NOM_PWM],strerror(errno));
				sprintf(senbuff,"d NG i2c neck error");
			}	else
			{
				sprintf(senbuff,"d OK");
			}*/
			
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending neck down") );
			}
			break;
		
		case 'a': // move neck to Switch low
			#ifdef DEBUG
			printf("DEBUG: Move neck to switch Low\n");
			#endif
			
			if (neck_low()!=0) {
				sprintf(senbuff,"a NG");
			} else
			{
				sprintf(senbuff,"a OK");
			}
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending neck angle") );
			}
			break;

		case 'o': // move robot to origin
			#ifdef DEBUG
			printf("DEBUG: Move robot to origin!\n");
			#endif
			
			if (mode_gotoxya!=0) {
				sprintf(senbuff,"o NG: already in goto mode");
			} else {
					sprintf(senbuff,"o OK");
					
					goal_a=0;
					goal_x=0;
					goal_y=0;
					
			}
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending robot origin") );
			}
			break;
			
        case 'c': // move neck to center
			#ifdef DEBUG
			printf("DEBUG: Move neck to center!\n");
			#endif
			
			if (neck_origin()!=0) {
				sprintf(senbuff,"c NG");
			} else
			{
				sprintf(senbuff,"c OK");
			}
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending neck center") );
			}
        break;
		
		case 's': // stop robot , stop pan/tilt,  shutdown or save parameters
			if ((strlen(recvbuff)>1 && (recvbuff[1]=='h'))) { 
				// shut down
				sprintf(senbuff,"sh OK");
				printf("\nShutting down the system\n");
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, sending shutdown") );
				}
				clear_gpio(led_gpio_nb);
				system("shutdown -h now"); // this command does not return?!!
				printf("Shutdown return\n");
				fflush(stdout);
				return -3;
				
			} else if ((strlen(recvbuff)>1 && (recvbuff[1]=='a'))) { 
				//save parameters
			
				if (save_settings()==0) {
					sprintf(senbuff,"sa OK");
					#ifdef DEBUG
					printf("DEBUG: saving parameters OK!\n");
					#endif

				} else
				{
					sprintf(senbuff,"sa NG");
					#ifdef DEBUG
					printf("DEBUG: saving parameters NOT OK!\n");
					#endif
				}

				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, saving parameters") );
				}

				
			} else if (strlen(recvbuff)==1) {
				// stop robot
				#ifdef DEBUG
				printf("DEBUG: Stopping the robot!\n");
				#endif
				
				current_a=0;
				current_x=0;
				current_y=0;
				
				if (stop_drive_motors()!=0) {
					sprintf(senbuff,"s NG");
				} else {
					sprintf(senbuff,"s OK");
				}
				
				if (mode_gotoxya!=0) {
					mode_gotoxya==0;
					set_drive_motors_mode(eCTRL_SPEED_ACC,eCTRL_SPEED_ACC);
				}
				
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, sending stop") );
				}
			
			}
			break;
				
		case 'p': // pan left, pan right, set parameter
			if ((strlen(recvbuff)>1 && (recvbuff[1]=='l'))) { 
				// pan left
				#ifdef DEBUG
				printf("\nDEBUG: pan left\n");
				#endif
				
				
				// Pelco D
				rsbuff[0]=0xff; // synchronization
				rsbuff[1]=PAN_TILT_PELCOD_ADDRESS;  // device address
				rsbuff[2]=0; // Command 1
				rsbuff[3]=PAN_TILT_PELCOD_COMMAND_2_PAN_LEFT; // Command 2
				rsbuff[4]=settings_value[ePAN_NOM_SPEED]; // Data 1
				rsbuff[5]=0; // Data 2
				rsbuff[6]=pelcod_checksum(rsbuff); // Checksum
				write(rs485_fd,rsbuff,RS485_PELCOD_CMD_SIZE  );
				
				sprintf(senbuff,"pl OK");		
				
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, pan left") );
				}
			} else if ((strlen(recvbuff)>1 && (recvbuff[1]=='r'))) { 
				// pan right
				
				// Pelco D
				rsbuff[0]=0xff; // synchronization
				rsbuff[1]=PAN_TILT_PELCOD_ADDRESS;  // device address
				rsbuff[2]=0; // Command 1
				rsbuff[3]=PAN_TILT_PELCOD_COMMAND_2_PAN_RIGHT; // Command 2
				rsbuff[4]=settings_value[ePAN_NOM_SPEED]; // Data 1
				rsbuff[5]=0; // Data 2
				rsbuff[6]=pelcod_checksum(rsbuff); // Checksum
				write(rs485_fd,rsbuff,RS485_PELCOD_CMD_SIZE  );
				
				
				sprintf(senbuff,"pr OK");
				#ifdef DEBUG
				printf("\nDEBUG: pan right\n");
				#endif
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, tilt down") );
				}
			} else if ((sscanf(recvbuff,"%*c %c %s %d",&cdata,&sdata,&idata))!=3) {	
				// invalid parameter
				printf("\nInvalid set parameter: %s\n",recvbuff);
				sprintf(senbuff,"INV %s", recvbuff);
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, sending set parameter") );
				}
			} else {	
				// param ok
				#ifdef DEBUG
				printf("DEBUG: %s received:\"%s\": mot=%c param=%s value=%d\n",__FUNCTION__,recvbuff,cdata,sdata,idata);	
				#endif
				
				// check motor type
				if (strchr("lrno",cdata)==NULL)	{
						printf("\nUnknown motor for set parameter: %c\n",cdata);
						sprintf(senbuff,"UP %c", cdata);
						if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0) {
							perror( const_cast<char *>("ERROR, sending set parameter") );
						}
				} else {
					// find and set parameter
					sprintf(buffer,"%s%s",cdata=='l'?"LEFT_":(cdata=='r'?"RIGHT_":(cdata=='n'?"NECK_":(cdata=='o'?"":"UKN_"))),sdata);
					#ifdef DEBUG
					printf("DEBUG: in %s: find %s param\n",__FUNCTION__,buffer);	
					#endif
					

					if (((errs=set_setting(buffer,idata))==0)  || ((errv=set_variable(buffer,idata))==0)) {  
						// OK
						#ifdef DEBUG
						printf("DEBUG: set parameter %s for motor %c found!\n",sdata,cdata);
						#endif
						sprintf(senbuff,"p %c %s", cdata,sdata);
						if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0) {
							perror( const_cast<char *>("ERROR, sending set parameter") );
						}
					} else {
					// ? i2c error
						if ((errs==-2) ||		(errv==-2))					{
							printf("\nERROR setting i2c parameter %s for motor %c\n",sdata,cdata);
							sprintf(senbuff,"IS %c %s", cdata,sdata);
						} else {
							// unknown setting
							printf("\nUnknown set parameter %s for motor %c\n",sdata,cdata);
							sprintf(senbuff,"UP %c %s", cdata,sdata);
						}
						if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0) {
							perror( const_cast<char *>("ERROR, sending set parameter") );
						}
					}
				}
			}
			break;
			
		case 'g': // goto defined position , get parameter
			if (strlen(recvbuff)==1) {
				// goto defined position
				if (mode_gotoxya==0) {
					// not in goto xya mode: set it
					mode_gotoxya=1;
					
					goal_a=settings_value[eGOAL_A];
					goal_x=settings_value[eGOAL_X];
					goal_y=settings_value[eGOAL_Y];
					
					sprintf(senbuff,"goto mode activated");

										
				} else {
					
					sprintf(senbuff,"g NG already in goto mode");

				}	
				
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, sending g activated") );
				}
			} else if ((sscanf(recvbuff,"%*c %c %s",&cdata,&sdata))!=2)	{	// invalid parameter
				printf("\nInvalid get parameter: %s\n",recvbuff);
				sprintf(senbuff,"INV %s", recvbuff);
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, sending get parameter") );
				}
			} else 
			{	// param ok
				#ifdef DEBUG
				printf("DEBUG: %s received:\"%s\": mot=%c param=%s\n",__FUNCTION__,recvbuff,cdata,sdata);	
				#endif
				
				// check motor type
				if (strchr("lrno",cdata)==NULL)	{
						printf("\nUnknown motor for get parameter: %c\n",cdata);
						sprintf(senbuff,"UG %c", cdata);
						if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0) {
							perror( const_cast<char *>("ERROR, sending get parameter") );
						}
				} else {
					// find and get parameter
					sprintf(buffer,"%s%s",cdata=='l'?"LEFT_":(cdata=='r'?"RIGHT_":(cdata=='n'?"NECK_":(cdata=='o'?"":"UKN_"))),sdata);
					#ifdef DEBUG
					printf("DEBUG: in %s: find %s param\n",__FUNCTION__,buffer);	
					#endif
					// is param in any of the settings or variables ?
					if (((errs=get_setting(buffer,&idata))==0)  || ((errv=get_variable(buffer,&idata))==0)) {  
						// OK
						#ifdef DEBUG
						printf("DEBUG: get parameter %s for motor %c found:%d!\n",sdata,cdata,idata);
						#endif
								
						
						sprintf(senbuff,"g %c %s %d", cdata,sdata,idata);
						if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0) {
							perror( const_cast<char *>("ERROR, sending set parameter") );
						}
					} else { 
					// ? i2c error
						if ((errs==-2) ||		(errv==-2))					{
							printf("\nERROR getting i2c parameter %s for motor %c\n",sdata,cdata);
							sprintf(senbuff,"IG %c %s", cdata,sdata);
						} else {
							// unknown setting
							printf("\nUnknown get parameter %s for motor %c\n",sdata,cdata);
							sprintf(senbuff,"UG %c %s", cdata,sdata);
						}
						if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0) {
							perror( const_cast<char *>("ERROR, sending get parameter") );
						}
					}
				}	
			}
			break;	

		case 't': // tilt up/down
			if ((strlen(recvbuff)>1 && (recvbuff[1]=='u'))) { 
				// tilt up
				
				#ifdef DEBUG
				printf("\nDEBUG: tilt up\n");
				#endif
				
				// Pelco D
				rsbuff[0]=0xff; // synchronization
				rsbuff[1]=PAN_TILT_PELCOD_ADDRESS;  // device address
				rsbuff[2]=0; // Command 1
				rsbuff[3]=PAN_TILT_PELCOD_COMMAND_2_TILT_UP; // Command 2
				rsbuff[4]=0; // Data 1
				rsbuff[5]=settings_value[eTILT_NOM_SPEED]; // Data 2
				rsbuff[6]=pelcod_checksum(rsbuff); // Checksum
				write(rs485_fd,rsbuff,RS485_PELCOD_CMD_SIZE  );
				
				sprintf(senbuff,"tu OK");
				
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, tilt up") );
				}
			} else if ((strlen(recvbuff)>1 && (recvbuff[1]=='d'))) { 
				// tilt down
				
				#ifdef DEBUG
				printf("\nDEBUG: tilt down\n");
				#endif
				
				// Pelco D
				rsbuff[0]=0xff; // synchronization
				rsbuff[1]=PAN_TILT_PELCOD_ADDRESS;  // device address
				rsbuff[2]=0; // Command 1
				rsbuff[3]=PAN_TILT_PELCOD_COMMAND_2_TILT_DOWN; // Command 2
				rsbuff[4]=0; // Data 1
				rsbuff[5]=settings_value[eTILT_NOM_SPEED]; // Data 2
				rsbuff[6]=pelcod_checksum(rsbuff); // Checksum
				write(rs485_fd,rsbuff,RS485_PELCOD_CMD_SIZE  );
				
				sprintf(senbuff,"td OK");
				
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, tilt down") );
				}
		  } else {
				printf("\nUnknown command: %s\n",recvbuff);
				sprintf(senbuff,"UC %s", recvbuff);
			}
			break;	
		
		case 'z': // stop pan/tilt				
				#ifdef DEBUG
				printf("\nDEBUG: stop pan/tilt\n");
				#endif
				if (stop_pan_tilt()!=0) {
					sprintf(senbuff,"z NG");
				} else {
					sprintf(senbuff,"z OK");
				}
				
				if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
				{
					perror( const_cast<char *>("ERROR, stop pan/tilt") );
				}
				
		break;
		
		default:
			printf("\nUnknown command: %s\n",recvbuff);
			sprintf(senbuff,"UC %s", recvbuff);
			if(sendSocketData(sockfd,senbuff,strlen(senbuff)) <0)
			{
				perror( const_cast<char *>("ERROR, sending shutdown") );
			}
	}
	

	
	
	return 0;
}

/*---------------------------- MAIN ----------------------------------*/
/*--------------------------------------------------------------------*/
/*!
 * Main program
 *
 * \param argc number of arguments
					argv array of null terminated char argument
 *
 * \return 0 for success, otherwise <0
 */
int main(int argc, char *argv[]) {
	int sockfd,portno = DEFAULfT_SERVER_PORT, clilen;
	char buffer[256],chbuff[SOCKET_MAX_SIZE+1];;
	struct sockaddr_in serv_addr, cli_addr;
	int n;
	int data;
	int retxya;
	double dist2goal,angle2goal; // distance/angle to goal 	
	int left,right;
	struct timeval auto_startt, auto_endt;

	printf("\nPAH server program (compiled on %s at %s)\n\n",__DATE__,__TIME__);
	
	// test array size at compilation (nothing remains in binary)
	BUILD_BUG_ON(SETTINGS_NUMBER != (sizeof(settings_scantype)/sizeof(*settings_scantype)));
	BUILD_BUG_ON(SETTINGS_NUMBER != (sizeof(settings_printtype)/sizeof(*settings_printtype)));
	BUILD_BUG_ON(SETTINGS_NUMBER != (sizeof(settings_i2csize)/sizeof(*settings_i2csize)));
	BUILD_BUG_ON(SETTINGS_NUMBER != (sizeof(settings_i2creg)/sizeof(*settings_i2creg)));
	BUILD_BUG_ON(SETTINGS_NUMBER != (sizeof(settings_board)/sizeof(*settings_board)));

	BUILD_BUG_ON(VARIABLES_NUMBER != (sizeof(variables_scantype)/sizeof(*variables_scantype)));
	BUILD_BUG_ON(VARIABLES_NUMBER != (sizeof(variables_printtype)/sizeof(*variables_printtype)));
	BUILD_BUG_ON(VARIABLES_NUMBER != (sizeof(variables_i2csize)/sizeof(*variables_i2csize)));
	BUILD_BUG_ON(VARIABLES_NUMBER != (sizeof(variables_i2creg)/sizeof(*variables_i2creg)));
	BUILD_BUG_ON(VARIABLES_NUMBER != (sizeof(variables_board)/sizeof(*variables_board)));
	
	// load settings file
	printf("Loading settings from file \"" SETTINGS_FILENAME "\"\n");
	if (load_settings()<0)
	{
		if (errno>0)
			perror("ERROR: Could not load settings file " SETTINGS_FILENAME);		
		else
			fprintf(stderr,"ERROR: Could not load settings file " SETTINGS_FILENAME "!\n");
    exit(-1);
	}
	

	// open i2c
	printf("Opening i2c device %s...\n",I2C_DEV);
	if (i2c_open()!=0) {
		perror("ERROR: open i2c");
    exit(-2);
	}

	int err=0;
	// test i2c board connection
	for (int i=0;i<3;i++)
	{	
		if (!i2c_exists(boards_i2c_addr[i]))
		{
			err--;
			fprintf(stderr,"ERROR: Could connect to i2c board %s address 0x%x!\n",boards_name[i],boards_i2c_addr[i]);
		} 
		else
		{
			#ifdef DEBUG
			printf("DEBUG: i2c board %s exist.\n",boards_name[i]);
			#endif
		}
	}
	
	/* //TO DO: does not exit
	if (err<0)
	{
		printf("\nError accessing a i2c board, exiting program!\n");
		i2c_close();
		exit(-2);
	}*/
		
	
	if (send_i2c_all_settings()!=0) {
		perror("ERROR: sending all i2c settings");
	}
	
	

	
	// stop robot and set motors modes
	stop_drive_motors();
	set_drive_motors_mode(eCTRL_SPEED_ACC,eCTRL_SPEED_ACC);
	
	// set neck mode
	stop_neck_motor();
	set_neck_motor_mode(eCTRL_OPEN_LOOP);
	
	
	/* open the port */
  printf("Opening RS485 serial port %s...\n", RS485_DEVICE);
  if ( (rs485_fd = open(RS485_DEVICE, O_RDWR | O_NOCTTY | O_NDELAY)) < 0 )
  {
    printf("failed.\n");
    printf("possible causes:\n");
    printf("1) the raspicomm device driver is not loaded. type 'lsmod' and verify that you 'raspicommrs485' is loaded.\n");
    printf("2) the raspicomm device driver is in use. Is another application using the device driver?\n" );
    printf("3) something went wrong when loading the device driver. type 'dmesg' and check the kernel messages\n");
		i2c_close();
    exit(-3);
  }
	
	/* configure the RS485 port */
  if (set_interface_attribs(rs485_fd, RS485_SPEED, 0) < 0) {
    printf("Error configuring the rs-485 port.\n");
		close(rs485_fd);
		i2c_close();
    exit(-4);
  }
	
	
	#ifdef DEBUG
	printf("\nDEBUG: !!!!\n");
	printf("DEBUG: !!!! NO neck initialisation!!\n");
	printf("DEBUG: !!!!\n\n");
	#endif
	//if (init_neck()!=0) {
	//	printf("Error initialising neck!\n");
	//}
	
	// set the ctrl-c handler
	signal( SIGINT , ctrlc_handler );
	
	printf( "using tcp/ip port #%d\n", portno );
	
	

	// create a socket
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		perror( const_cast<char *>("ERROR opening socket") );
		close(rs485_fd);
		i2c_close();
		exit(-5);
	}	 
	
	
	
	/*
	 * turn off bind address checking, and allow
	 * port numbers to be reused - otherwise
	 * the TIME_WAIT phenomenon will prevent
	 * binding to these address.port combinations
	 * for (2 * MSL) seconds.
	 */

	int on = 1;

	int status = setsockopt(sockfd, SOL_SOCKET,
		SO_REUSEADDR,
			(const char *) &on, sizeof(on));

	if (-1 == status)
	{
		perror("setsockopt(...,SO_REUSEADDR,...)");
		close(rs485_fd);
		i2c_close();
		exit(-6);
	}
	
	// and make it non blocking
	int flags = fcntl(sockfd, F_GETFL, 0);
	if (flags < 0) 	{
		perror( const_cast<char *>( "ERROR getting socket mode") );
		close(rs485_fd);
		i2c_close();
		exit(-7);
		}
	flags =  flags|O_NONBLOCK;
	if (fcntl(sockfd, F_SETFL, flags) != 0)	{
		perror( const_cast<char *>( "ERROR enabling non-blocking mode to socket") );
		close(rs485_fd);
		i2c_close();
		exit(-8);
	}
	
	bzero((char *) &serv_addr, sizeof(serv_addr));

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons( portno );
	// bind the socket to any address and the specified port
	if (bind(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)  {
		perror( const_cast<char *>( "ERROR on binding" ) );
		close(rs485_fd);
		i2c_close();
		exit(-9);
	}  
	
	// listen to the socket
	listen(sockfd,5);
	clilen = sizeof(cli_addr);

	// init and set gpio led to on
	if (init_gpio(led_gpio_nb,0)<0) {
		printf("ERROR: could not initialize gpio %d!\n",led_gpio_nb);
	} else {
		// init gpio led ok
		set_gpio(led_gpio_nb);
	}
		
	printf( "waiting for new client..." );
	fflush(stdout);
	
	
	
	//--- infinite wait on a connection ---
	while ( 1 ) {
		
		#ifdef DEBUG 
		printf("."); fflush(stdout);usleep(200000);
		#else
		usleep(1000);
		#endif
		
		
		if (quitReq) {
			break;
		}
		
		// accept the socket connection
		if ( ( newsockfd = accept( sockfd, (struct sockaddr *) &cli_addr, (socklen_t*) &clilen) ) < 0 ) {
			if (errno != EAGAIN) {
				perror( const_cast<char *>("\nERROR on accept socket") );
			}	
			continue; //break;
		}	
		
		printf( "\nNew connection with client\n" );
		
		int flags = fcntl(newsockfd, F_GETFL, 0);
		if (flags < 0) 	{
			perror( const_cast<char *>( "ERROR getting new socket mode") );
			i2c_close();
			exit(-10);
			}
		flags =  flags|O_NONBLOCK;
		if (fcntl(newsockfd, F_SETFL, flags) != 0)	{
			perror( const_cast<char *>( "ERROR enabling non-blocking mode to new socket") );
			i2c_close();
			exit(-11);
		}

		int nberr=0,nberrnotcorr=0;
		
		// client accepted; loop and proceed client requests
		gettimeofday(&auto_startt, NULL);
		auto_p=0;
		auto_s=0;
		while ( 1 ) {
			
			#ifdef DEBUG 
			printf("*"); fflush(stdout);usleep(100000);
			#else
			usleep(1000);
			#endif
			
		
			// if any data from socket, proceed
			if (proceed_net_data(newsockfd) <0)
			{	// error occurred => release connection
				break;
			}
			
			
			if (auto_p || auto_s) {
				gettimeofday(&auto_endt, NULL);
				int secs_used=(auto_endt.tv_sec - auto_startt.tv_sec); //avoid overflow by subtracting first
				int micros_used= ((secs_used*1000000) + auto_endt.tv_usec) - (auto_startt.tv_usec);
				
				if (micros_used>AUTO_TIME) {
					gettimeofday(&auto_startt, NULL);
					
					if (auto_p) {
						// send position
						if (get_drive_position(&left,&right)!=0) {
							sprintf(chbuff,"e NG");
						} else {
							sprintf(chbuff,"e L:%10d  R:%10d",left,right);
						}
					
						if(sendSocketData(newsockfd,chbuff,strlen(chbuff)) <0) {
							perror( const_cast<char *>("ERROR, sending e") );
						}
					}

					if (auto_s) {
						if (get_drive_speed(&left,&right)!=0) {
							sprintf(chbuff,"v NG");
						} else {
							sprintf(chbuff,"v L:%10d  R:%10d",left,right);
						}
					
						if(sendSocketData(newsockfd,chbuff,strlen(chbuff)) <0) {
							perror( const_cast<char *>("ERROR, sending v") );
						}
					}
				}
			}
			
			if (mode_gotoxya) // in goto xya mode ?
			{
				retxya=goto_xya(current_x,current_y,current_a,goal_x,goal_y,goal_a,&dist2goal,&angle2goal);
				if (retxya==0) // end of goto
				{
					mode_gotoxya=0;
					#ifdef DEBUG
					printf("DEBUG: Goal reached!");
					#endif
					
					sprintf(chbuff,"Goal reached!");
					if(sendSocketData(newsockfd,chbuff,strlen(chbuff)) <0)
					{
						perror( const_cast<char *>("ERROR, sending shutdown") );
					}
					
				}	else
				{	// display goal
					
					// printf("Moving to goal: x=%6.1f y=%6.1f angle=%6.1f (remaining: distance= %6.1f  angle= %6.1f)",goal_x,goal_y,goal_a,dist2goal,angle2goal);
				}
			}	
			
			if (quitReq)
			{
				break;
			}

		}
		close( newsockfd );
		
		
		if (quitReq)
			break;
		
		printf( "Waiting for new client..." );	
	}
	
	close(sockfd );
	
	close(rs485_fd);
	
	// stop robot
	stop_drive_motors();
	set_drive_motors_mode(eCTRL_SPEED_ACC,eCTRL_SPEED_ACC);
	usleep(500000);
	set_drive_motors_mode(eCTRL_IDLE,eCTRL_IDLE);
	
	i2c_close();
	
	// clear and release GPIO LED
	clear_gpio(led_gpio_nb);
	if (release_gpio(led_gpio_nb)<0)
	{
		printf("ERROR: could not release gpio %d!\n",led_gpio_nb);
	}
		
	
	printf("\nSaving used settings at exit to file \"" SETTINGS_FILENAME "\"\n");
	if (save_settings()<0)
	{
		if (errno>0)
			perror("ERROR: Could not save settings file " SETTINGS_FILENAME);		
		else
			fprintf(stderr,"ERROR: Could not save settings file " SETTINGS_FILENAME "!\n");
	}
	
	printf("\n\nApplication exiting normally\n\n");
	return 0;
}
