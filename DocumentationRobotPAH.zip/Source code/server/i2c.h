//--------------------------------------------------------------------------------//
//-                   KJ_EVO ( K-Junior extension board			 )                     -//
//                                                                               -//
//-  Copyright (C) Julien Tharin, K-Team S.A. 2011                               -//
//-  This library is free software; you can redistribute it and/or               -//
//-  modify it under the terms of the GNU Lesser General Public                  -//
//-  License as published by the Free Software Foundation; either                -//
//-  version 2.1 of the License, or any later version.                           -//
//-                                                                              -//
//-  This library is distributed in the hope that it will be useful,             -//
//-  but WITHOUT ANY WARRANTY; without even the implied warranty of              -//
//-  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU           -//
//-  Lesser General Public License for more details.                             -//
//-                                                                              -//
//-  You should have received a copy of the GNU Lesser General Public            -//
//-  License along with this library; if not, write to the Free Software         -//
//-  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   -//
//-                                                                              -//
//-                               __  __  ________                               -//
//- K-Team S.A.                  |  |/  /|__    __|___  _____  ___  ___          -//
//- Rue Galilee 9. Y-Park,       |     / __ |  | _____|/  _  \|   \/   |         -//
//- 1400 Yverdon-les-Bains       |  |  \    |  | ____|/  /_\  |        |         -//
//- Switzerland                  |__|\__\   |__|______|_/   \_|__|\/|__|         -//
//- jtharin@k-team.com   tel:+41 24 423 89 75 fax:+41 24 423 8960                -//
//-                                                                              -//
//--------------------------------------------------------------------------------//

////////////////////////////////////////////////////////////////////////////////
/*!   \file i2c.h
      \brief header of Functions for using the i2c of the K-Junior extension board
*/
////////////////////////////////////////////////////////////////////////////////

#ifndef __i2c__
#define __i2c__



#define I2C_DEV "/dev/i2c-1"  // i2c device

#define I2C_BLOCK_MAX_ERROR -4321


/*--------------------------------------------------------------------
 * Public Prototypes Declaration
 */

extern int i2c_already_open;

extern int i2c_open();

extern int i2c_priv_select_device(char address);

extern void i2c_close();

extern int  i2c_read(char dev_address, char reg_address, char * buf , unsigned int len );

extern int  i2c_write(char dev_address, char reg_address, const char * buf , unsigned int len );


extern int  i2c_transfer( char dev,
			     const char * write_buf ,
			    unsigned int write_len ,
			    char * read_buf ,
			    unsigned int read_len );

extern int   i2c_exists( char dev );

extern int   i2c_scan(
		       int (*callback)(char dev,
						void * context ) ,
		       void * context);
		       
		       

#endif /* __i2c__ */
